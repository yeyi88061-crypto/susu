
import { Character, Message, AppSettings, DEFAULT_SETTINGS, DEFAULT_CHARACTER, LUMI_CHARACTER, WorldBook, Sticker } from './types';

const DB_NAME = 'MonoChatDB';
const DB_VERSION = 3; // Bump version for stickers

export class DB {
  private db: IDBDatabase | null = null;

  async open(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('characters')) {
          db.createObjectStore('characters', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('messages')) {
          const msgStore = db.createObjectStore('messages', { keyPath: 'id' });
          msgStore.createIndex('timestamp', 'timestamp', { unique: false });
          msgStore.createIndex('characterId', 'characterId', { unique: false });
        }
        if (!db.objectStoreNames.contains('worldbooks')) {
          db.createObjectStore('worldbooks', { keyPath: 'id' });
        }
        // New store for Stickers
        if (!db.objectStoreNames.contains('stickers')) {
            db.createObjectStore('stickers', { keyPath: 'id' });
        }
      };

      request.onsuccess = (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        this.initDefaults().then(resolve);
      };

      request.onerror = (event) => {
        reject((event.target as IDBOpenDBRequest).error);
      };
    });
  }

  private async initDefaults() {
    // Check if settings exist, if not create default
    const settings = await this.getSettings();
    if (!settings) {
      await this.saveSettings(DEFAULT_SETTINGS);
    }
    
    // FORCE UPDATE SYSTEM CHARACTERS
    // This ensures that when we change the code (personality), 
    // it reflects in the app without the user needing to delete the character.
    await this.saveCharacter(DEFAULT_CHARACTER);
    await this.saveCharacter(LUMI_CHARACTER);
  }

  async getSettings(): Promise<AppSettings | null> {
    return new Promise((resolve) => {
      if (!this.db) return resolve(null);
      const tx = this.db.transaction('settings', 'readonly');
      const store = tx.objectStore('settings');
      const req = store.get('global_settings');
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  }

  async saveSettings(settings: AppSettings): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.db) return reject('DB not open');
      const tx = this.db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');
      // Always store with fixed id
      const req = store.put({ ...settings, id: 'global_settings' });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getAllCharacters(): Promise<Character[]> {
    return new Promise((resolve) => {
      if (!this.db) return resolve([]);
      const tx = this.db.transaction('characters', 'readonly');
      const store = tx.objectStore('characters');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
    });
  }

  async saveCharacter(character: Character): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.db) return reject('DB not open');
      const tx = this.db.transaction('characters', 'readwrite');
      const store = tx.objectStore('characters');
      const req = store.put(character);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async deleteCharacter(id: string): Promise<void> {
    return new Promise((resolve, reject) => {
       if (!this.db) return reject('DB not open');
       const tx = this.db.transaction('characters', 'readwrite');
       const store = tx.objectStore('characters');
       const req = store.delete(id);
       req.onsuccess = () => resolve();
       req.onerror = () => reject(req.error);
    });
  }

  async getMessages(characterId: string): Promise<Message[]> {
    return new Promise((resolve) => {
      if (!this.db) return resolve([]);
      const tx = this.db.transaction('messages', 'readonly');
      const store = tx.objectStore('messages');
      // In a real app we might use an index, but for simple local use filtering in memory is fine for < 1000 msgs
      const req = store.getAll();
      req.onsuccess = () => {
        const all = req.result as Message[];
        // Filter and sort
        const filtered = all.filter(m => m.characterId === characterId).sort((a, b) => a.timestamp - b.timestamp);
        resolve(filtered);
      };
    });
  }

  async getCharacterStats(characterId: string): Promise<{ count: number, startTime: number }> {
      return new Promise((resolve) => {
          if (!this.db) return resolve({ count: 0, startTime: 0 });
          const tx = this.db.transaction('messages', 'readonly');
          const store = tx.objectStore('messages');
          // Filter manually for simplicity
          const req = store.getAll(); 
          req.onsuccess = () => {
               const all = req.result as Message[];
               const chars = all.filter(m => m.characterId === characterId);
               if (chars.length === 0) return resolve({ count: 0, startTime: 0 });
               
               // Sort to find first. 
               // Note: 'all' might not be sorted by default depending on DB implementation, so sorting is safe.
               chars.sort((a,b) => a.timestamp - b.timestamp);
               
               resolve({ count: chars.length, startTime: chars[0].timestamp });
          }
          req.onerror = () => resolve({ count: 0, startTime: 0 });
      });
  }

  async saveMessage(message: Message): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.db) return reject('DB not open');
      const tx = this.db.transaction('messages', 'readwrite');
      const store = tx.objectStore('messages');
      const req = store.put(message);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }
  
  async clearMessages(characterId: string): Promise<void> {
      return new Promise((resolve, reject) => {
          if(!this.db) return reject('DB not open');
          const tx = this.db.transaction('messages', 'readwrite');
          const store = tx.objectStore('messages');
          const req = store.getAll(); // Inefficient for massive DBs but fine here
          req.onsuccess = () => {
              const all = req.result as Message[];
              const toDelete = all.filter(m => m.characterId === characterId);
              toDelete.forEach(m => store.delete(m.id));
              resolve();
          }
      })
  }

  async deleteMessages(ids: string[]): Promise<void> {
      return new Promise((resolve, reject) => {
          if (!this.db) return reject('DB not open');
          const tx = this.db.transaction('messages', 'readwrite');
          const store = tx.objectStore('messages');
          
          ids.forEach(id => {
              store.delete(id);
          });
          
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error);
      });
  }

  // --- World Book Operations ---

  async getAllWorldBooks(): Promise<WorldBook[]> {
    return new Promise((resolve) => {
      if (!this.db) return resolve([]);
      if (!this.db.objectStoreNames.contains('worldbooks')) return resolve([]);
      
      const tx = this.db.transaction('worldbooks', 'readonly');
      const store = tx.objectStore('worldbooks');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
    });
  }

  async saveWorldBook(wb: WorldBook): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.db) return reject('DB not open');
      const tx = this.db.transaction('worldbooks', 'readwrite');
      const store = tx.objectStore('worldbooks');
      const req = store.put(wb);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async deleteWorldBook(id: string): Promise<void> {
    return new Promise((resolve, reject) => {
       if (!this.db) return reject('DB not open');
       const tx = this.db.transaction('worldbooks', 'readwrite');
       const store = tx.objectStore('worldbooks');
       const req = store.delete(id);
       req.onsuccess = () => resolve();
       req.onerror = () => reject(req.error);
    });
  }

  // --- Sticker Operations ---

  async getAllStickers(): Promise<Sticker[]> {
      return new Promise((resolve) => {
          if (!this.db) return resolve([]);
          if (!this.db.objectStoreNames.contains('stickers')) return resolve([]);
          const tx = this.db.transaction('stickers', 'readonly');
          const store = tx.objectStore('stickers');
          const req = store.getAll();
          req.onsuccess = () => resolve(req.result || []);
      });
  }

  async saveSticker(sticker: Sticker): Promise<void> {
      return new Promise((resolve, reject) => {
          if (!this.db) return reject('DB not open');
          const tx = this.db.transaction('stickers', 'readwrite');
          const store = tx.objectStore('stickers');
          const req = store.put(sticker);
          req.onsuccess = () => resolve();
          req.onerror = () => reject(req.error);
      });
  }

  async deleteSticker(id: string): Promise<void> {
      return new Promise((resolve, reject) => {
          if (!this.db) return reject('DB not open');
          const tx = this.db.transaction('stickers', 'readwrite');
          const store = tx.objectStore('stickers');
          const req = store.delete(id);
          req.onsuccess = () => resolve();
          req.onerror = () => reject(req.error);
      });
  }

  async saveStickersBulk(stickers: Sticker[]): Promise<void> {
      return new Promise((resolve, reject) => {
          if (!this.db) return reject('DB not open');
          const tx = this.db.transaction('stickers', 'readwrite');
          const store = tx.objectStore('stickers');
          stickers.forEach(s => store.put(s));
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error);
      });
  }
}

export const db = new DB();