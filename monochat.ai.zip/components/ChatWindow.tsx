

import React, { useRef, useEffect, useState } from 'react';
import { Message, Character, AppSettings, WorldBook, Sticker, PrankData } from '../types';
import { Icons } from './Icons';
import MessageBubble from './MessageBubble';
import SpecialEvents from './LumiSpecials';
import EchoPranks from './EchoPranks'; // We need this to view archived pranks locally or trigger parent

interface Props {
  onOpenMenu: () => void;
  activeCharacter?: Character;
  settings: AppSettings;
  worldBooks: WorldBook[];
  stickers: Sticker[]; // Received from parent
  messages: Message[];
  isLoading: boolean;
  onSendMessage: (text: string, quote?: Message, type?: 'text' | 'voice' | 'image', duration?: number) => void;
  onTriggerAI: () => void;
  onCopyMessage: (text: string) => void;
  onDeleteMessages: (ids: string[]) => void;
  onlineStatus?: 'online' | 'offline';
  offlineActivity?: string;
  isTracingLoading?: boolean;
  onTrace?: () => void;
  onSummon?: () => void;
  onUpdateCharacter?: (char: Character) => void;
}

const ChatWindow: React.FC<Props> = ({
  onOpenMenu,
  activeCharacter,
  settings,
  worldBooks,
  stickers,
  messages,
  isLoading,
  onSendMessage,
  onTriggerAI,
  onCopyMessage,
  onDeleteMessages,
  onlineStatus = 'online',
  offlineActivity,
  isTracingLoading = false,
  onTrace,
  onSummon,
  onUpdateCharacter
}) => {
  const [inputVal, setInputVal] = useState('');
  const [activeMsgId, setActiveMsgId] = useState<string | null>(null);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  
  // Input Modes
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  const [showStickerPicker, setShowStickerPicker] = useState(false);
  const [isVoiceMode, setIsVoiceMode] = useState(false); // If true, send button sends voice message
  
  // Delete Mode State
  const [isDeleteMode, setIsDeleteMode] = useState(false);
  const [selectedMsgIds, setSelectedMsgIds] = useState<Set<string>>(new Set<string>());
  
  // Trace Modal
  const [showTraceModal, setShowTraceModal] = useState(false);
  
  // Theme Modal
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [themeBg, setThemeBg] = useState('');
  const [themeCss, setThemeCss] = useState('');
  const [boundWorldBookIds, setBoundWorldBookIds] = useState<string[]>([]);
  const [boundCategories, setBoundCategories] = useState<string[]>([]);

  // Artifacts (Lumi or Echo)
  const [showArtifacts, setShowArtifacts] = useState(false);
  const [viewingArtifact, setViewingArtifact] = useState<'apology' | 'recall' | 'note' | 'echo_radio' | 'echo_warning' | 'echo_confession' | null>(null);
  
  // Viewing Dynamic Echo Prank
  const [viewingPrank, setViewingPrank] = useState<PrankData | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Lumi Offline Calculation
  const isLumiOffline = activeCharacter?.id === 'lumi_ai' && 
                        activeCharacter.metadata?.offline_until && 
                        Date.now() < activeCharacter.metadata.offline_until;

  // Filter visible messages
  const visibleMessages = messages.filter(m => !m.isHidden);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, replyingTo]);

  // Reset local state when char changes
  useEffect(() => {
    setActiveMsgId(null);
    setReplyingTo(null);
    setInputVal('');
    setIsDeleteMode(false);
    setSelectedMsgIds(new Set());
    setShowTraceModal(false);
    setShowThemeModal(false);
    setShowPlusMenu(false);
    setShowStickerPicker(false);
    setIsVoiceMode(false);
    setShowArtifacts(false);
    setViewingArtifact(null);
    setViewingPrank(null);
    
    // Load character theme
    if (activeCharacter) {
        setThemeBg(activeCharacter.backgroundImage || '');
        setThemeCss(activeCharacter.bubbleCss || '');
        // Load bindings
        setBoundWorldBookIds(activeCharacter.worldBookIds || (activeCharacter.worldBookId ? [activeCharacter.worldBookId] : []));
        setBoundCategories(activeCharacter.worldBookCategories || []);
    }
  }, [activeCharacter?.id]);

  useEffect(() => {
    const handleClickOutside = () => {
        setActiveMsgId(null);
        setShowPlusMenu(false);
    };
    window.addEventListener('click', handleClickOutside);
    return () => window.removeEventListener('click', handleClickOutside);
  }, []);

  const formatDateSeparator = (ts: number) => {
    const date = new Date(ts);
    const now = new Date();
    const isSameYear = date.getFullYear() === now.getFullYear();
    const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    if (date.toDateString() === now.toDateString()) {
        return `今天 ${timeStr}`;
    }
    
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
        return `昨天 ${timeStr}`;
    }
    
    const dateStr = date.toLocaleDateString('zh-CN', {
        year: isSameYear ? undefined : 'numeric',
        month: 'numeric',
        day: 'numeric'
    });
    
    return `${dateStr} ${timeStr}`;
  };

  const handleTraceClick = () => {
      setShowTraceModal(true);
      if (onTrace && !offlineActivity) {
          onTrace();
      }
  };

  const handleRefreshTrace = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (onTrace) onTrace();
  };

  const handleSummonClick = () => {
      if (onSummon) {
          onSummon();
          setShowTraceModal(false);
      }
  };

  const handleSaveTheme = () => {
      if (activeCharacter && onUpdateCharacter) {
          onUpdateCharacter({
              ...activeCharacter,
              backgroundImage: themeBg,
              bubbleCss: themeCss,
              worldBookIds: boundWorldBookIds,
              worldBookCategories: boundCategories,
              worldBookId: undefined // Clear legacy field
          });
          setShowThemeModal(false);
      }
  };
  
  const toggleWorldBook = (id: string) => {
      setBoundWorldBookIds(prev => {
          if (prev.includes(id)) {
              return prev.filter(item => item !== id);
          } else {
              return [...prev, id];
          }
      });
  };

  const toggleCategory = (cat: string) => {
      setBoundCategories(prev => {
          if (prev.includes(cat)) {
              return prev.filter(item => item !== cat);
          } else {
              return [...prev, cat];
          }
      });
  };
  
  // Plus Menu Actions
  const handleToggleVoiceMode = (e: React.MouseEvent) => {
      e.stopPropagation();
      setIsVoiceMode(!isVoiceMode);
      setShowPlusMenu(false);
      setShowStickerPicker(false);
      setTimeout(() => inputRef.current?.focus(), 100);
  };

  const handleToggleStickerPicker = (e: React.MouseEvent) => {
      e.stopPropagation();
      setShowStickerPicker(!showStickerPicker);
      setShowPlusMenu(false);
  };

  const handleSendSticker = (url: string) => {
      onSendMessage(url, undefined, 'image');
      setShowStickerPicker(false);
  };

  const categories = Array.from(new Set(worldBooks.map(wb => wb.category || '未分类').filter((c) => !!c))).sort();

  if (!activeCharacter) {
      return (
          <div className="flex-1 flex flex-col items-center justify-center bg-zinc-950 text-zinc-500 relative overflow-hidden">
              <div className="absolute top-4 left-4 md:hidden z-20">
                  <button onClick={onOpenMenu} className="p-2 bg-zinc-900 rounded-full text-white shadow-lg border border-zinc-800">
                      <Icons.Menu />
                  </button>
              </div>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-zinc-900/50 to-zinc-950 pointer-events-none"></div>
              <div className="z-10 text-center space-y-6 animate-fade-in p-4">
                  <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-zinc-900 border border-zinc-800 mb-4 shadow-2xl">
                      <div className="text-zinc-400">
                        <Icons.Sparkles />
                      </div>
                  </div>
                  <div>
                      <h1 className="text-4xl md:text-5xl font-mono font-bold text-white tracking-widest mb-2">MONO.CHAT</h1>
                      <div className="h-px w-32 bg-gradient-to-r from-transparent via-zinc-600 to-transparent mx-auto"></div>
                  </div>
                  <p className="text-sm font-mono uppercase tracking-widest opacity-60">System Online. Waiting for link...</p>
                  <div className="pt-8 text-xs text-zinc-600">
                      <p>请在左侧选择一个聊天对象以开始</p>
                      <p className="mt-1 opacity-50">Select an entity from the sidebar to initiate connection</p>
                  </div>
              </div>
          </div>
      );
  }

  const handleMessageClick = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (isDeleteMode) {
        const newSet = new Set(selectedMsgIds);
        if (newSet.has(id)) {
            newSet.delete(id);
        } else {
            newSet.add(id);
        }
        setSelectedMsgIds(newSet);
    } else {
        setActiveMsgId(activeMsgId === id ? null : id);
    }
  };

  const handleQuoteMessage = (e: React.MouseEvent, msg: Message) => {
    e.stopPropagation();
    setReplyingTo(msg);
    setActiveMsgId(null);
    inputRef.current?.focus();
  };

  const handleCopyWrapper = (e: React.MouseEvent, text: string) => {
    e.stopPropagation();
    onCopyMessage(text);
    setActiveMsgId(null);
  };

  const handleSend = () => {
    if (!inputVal.trim()) return;
    
    if (isVoiceMode) {
        const duration = Math.min(60, Math.max(1, Math.ceil(inputVal.length * 0.3)));
        onSendMessage(inputVal, replyingTo || undefined, 'voice', duration);
        setIsVoiceMode(false);
    } else {
        onSendMessage(inputVal, replyingTo || undefined, 'text');
    }
    
    setInputVal('');
    setReplyingTo(null);
  };

  const toggleDeleteMode = () => {
      setIsDeleteMode(!isDeleteMode);
      setSelectedMsgIds(new Set());
      setActiveMsgId(null);
  };

  const handleDeleteAction = () => {
      if (selectedMsgIds.size === 0) return;
      onDeleteMessages(Array.from(selectedMsgIds));
      setIsDeleteMode(false);
      setSelectedMsgIds(new Set());
  };

  const getSenderName = (msg: Message) => {
    if (msg.role === 'user') return '我';
    return activeCharacter ? activeCharacter.name : 'AI';
  };

  return (
    <div 
        className="flex-1 flex flex-col relative bg-zinc-950 w-full bg-cover bg-center transition-all duration-500"
        style={{ backgroundImage: activeCharacter.backgroundImage ? `url(${activeCharacter.backgroundImage})` : undefined }}
    >
      {activeCharacter.bubbleCss && (
          <style>{activeCharacter.bubbleCss}</style>
      )}

      {activeCharacter.backgroundImage && <div className="absolute inset-0 bg-black/40 pointer-events-none"></div>}

      {/* Header */}
      <div className={`h-16 border-b flex items-center px-4 md:px-6 backdrop-blur-md sticky top-0 z-10 justify-between transition-colors
          ${isDeleteMode ? 'bg-red-900/10 border-red-900/30' : 'bg-zinc-900/50 border-zinc-800'}`}>
          
          <div className="flex items-center gap-3">
             {!isDeleteMode && (
                <button onClick={onOpenMenu} className="md:hidden text-zinc-400 hover:text-white p-1">
                    <Icons.Menu />
                </button>
             )}

            {isDeleteMode ? (
                <div className="text-red-400 font-mono text-sm font-bold flex items-center gap-2">
                    <Icons.Trash />
                    <span>选择模式: {selectedMsgIds.size}</span>
                </div>
            ) : (
                <div className="flex items-center">
                    <div className="relative">
                        <img src={activeCharacter.avatar} className="w-8 h-8 rounded-full border border-white/20 object-cover" alt="header avatar"/>
                        <div className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-black
                            ${isLumiOffline ? 'bg-yellow-500 animate-pulse' : (onlineStatus === 'online' ? 'bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.5)]' : 'bg-zinc-500')}
                        `}></div>
                    </div>
                    
                    <div className="ml-3">
                        <div className="flex items-center gap-2">
                            <div className="text-sm font-bold text-white leading-tight drop-shadow-md">{activeCharacter.name}</div>
                            {isLumiOffline ? (
                                <span className="text-[9px] text-yellow-500 font-mono px-1.5 py-0.5 border border-yellow-900/50 bg-yellow-900/20 rounded">MAINTENANCE_MODE</span>
                            ) : (
                                onlineStatus === 'offline' && !isDeleteMode && (
                                    <button 
                                        onClick={handleTraceClick}
                                        className="flex items-center space-x-1 px-1.5 py-0.5 rounded bg-zinc-800/80 hover:bg-zinc-700 text-[9px] text-zinc-300 font-mono border border-zinc-700 transition-colors backdrop-blur-sm"
                                    >
                                        <Icons.Activity />
                                        <span>追踪</span>
                                    </button>
                                )
                            )}
                        </div>
                        <div className="text-[10px] text-zinc-400 uppercase tracking-wider hidden sm:block drop-shadow-sm">{activeCharacter.remark}</div>
                    </div>
                </div>
            )}
          </div>
          
           <div className="flex items-center gap-3">
               {isDeleteMode ? (
                   <div className="flex items-center space-x-2">
                       <button 
                           onClick={toggleDeleteMode}
                           className="px-3 py-1.5 text-xs text-zinc-400 hover:text-white bg-zinc-800 hover:bg-zinc-700 rounded transition-colors"
                       >
                           取消
                       </button>
                       <button 
                           onClick={handleDeleteAction}
                           disabled={selectedMsgIds.size === 0}
                           className="px-3 py-1.5 text-xs bg-red-600 text-white rounded hover:bg-red-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-bold whitespace-nowrap"
                       >
                           删除
                       </button>
                   </div>
               ) : (
                    <>
                        {/* SPECIAL EVENTS BUTTON (Archive) */}
                        {((activeCharacter.metadata?.events_triggered && activeCharacter.metadata.events_triggered.length > 0) || (activeCharacter.metadata?.echo_pranks_unlocked && activeCharacter.metadata.echo_pranks_unlocked.length > 0)) && (
                            <button
                                onClick={() => setShowArtifacts(true)}
                                title="档案 (Archive)"
                                className="p-2 text-zinc-500 hover:text-white hover:bg-white/10 rounded-full transition-colors relative"
                            >
                                <Icons.Book /> 
                                <span className="absolute top-1 right-1 w-2 h-2 bg-yellow-500 rounded-full"></span>
                            </button>
                        )}

                        <button 
                            onClick={() => setShowThemeModal(true)}
                            title="外观与世界书设置"
                            className="p-2 text-zinc-500 hover:text-white hover:bg-white/10 rounded-full transition-colors"
                        >
                            <Icons.Settings />
                        </button>
                        <button 
                            onClick={toggleDeleteMode}
                            title="删除记录"
                            className="p-2 text-zinc-500 hover:text-red-400 hover:bg-white/5 rounded-full transition-colors"
                        >
                            <Icons.Trash />
                        </button>
                    </>
               )}
           </div>
      </div>

      {/* Artifact List Modal (Lumi & Echo) */}
      {showArtifacts && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in" onClick={() => setShowArtifacts(false)}>
              <div className="w-full max-w-sm bg-zinc-900 border border-zinc-700 rounded-xl p-6 shadow-2xl overflow-y-auto max-h-[80vh]" onClick={e => e.stopPropagation()}>
                  <h3 className="text-sm font-mono font-bold uppercase text-zinc-400 mb-4 border-b border-zinc-800 pb-2">Archive: Memory_Logs</h3>
                  <div className="space-y-4">
                      {/* LUMI LOGS */}
                      {activeCharacter.id === 'lumi_ai' && (
                          <div className="space-y-2">
                             {activeCharacter?.metadata?.events_triggered?.includes(1000) && (
                                <button onClick={() => setViewingArtifact('apology')} className="w-full text-left p-3 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-mono text-blue-400 border border-blue-900/30">
                                    [LOG_1000] EFFICIENCY_REPORT.eml
                                </button>
                             )}
                             {activeCharacter?.metadata?.events_triggered?.includes(1500) && (
                                <button onClick={() => setViewingArtifact('recall')} className="w-full text-left p-3 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-mono text-red-500 border border-red-900/30">
                                    [LOG_1500] SYSTEM_ERROR_CRITICAL.eml
                                </button>
                             )}
                             {activeCharacter?.metadata?.events_triggered?.includes(2000) && (
                                <button onClick={() => setViewingArtifact('note')} className="w-full text-left p-3 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-mono text-white border border-zinc-600">
                                    [LOG_2000] note_for_you.txt
                                </button>
                             )}
                          </div>
                      )}

                      {/* ECHO LOGS */}
                      {activeCharacter.id === 'default_ai' && (
                          <>
                             {/* STORY EVENTS */}
                             <div className="space-y-2">
                                <div className="text-[10px] font-bold text-zinc-500 uppercase">Story Events</div>
                                {activeCharacter?.metadata?.events_triggered?.includes(1000) && (
                                    <button onClick={() => setViewingArtifact('echo_radio')} className="w-full text-left p-3 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-mono text-green-500 border border-green-900/30 flex items-center gap-2">
                                        <Icons.Wifi />
                                        <span>UNKNOWN_FREQUENCY.wav</span>
                                    </button>
                                )}
                                {activeCharacter?.metadata?.events_triggered?.includes(1500) && (
                                    <button onClick={() => setViewingArtifact('echo_warning')} className="w-full text-left p-3 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-mono text-yellow-500 border border-yellow-900/30">
                                        [ITEM] crumpled_paper_ball.obj
                                    </button>
                                )}
                                {activeCharacter?.metadata?.events_triggered?.includes(1800) && (
                                    <button onClick={() => setViewingArtifact('echo_confession')} className="w-full text-left p-3 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-mono text-white border border-zinc-500">
                                        [MSG] THE_TRUTH.txt
                                    </button>
                                )}
                             </div>

                             {/* DYNAMIC PRANKS */}
                             {activeCharacter?.metadata?.echo_pranks_unlocked && activeCharacter.metadata.echo_pranks_unlocked.length > 0 && (
                                 <div className="space-y-2 pt-2 border-t border-zinc-800">
                                     <div className="text-[10px] font-bold text-zinc-500 uppercase">Unlocked Echo's Tricks ({activeCharacter.metadata.echo_pranks_unlocked.length})</div>
                                     <div className="grid gap-2">
                                         {activeCharacter.metadata.echo_pranks_unlocked.slice().reverse().map((prank, idx) => (
                                             <button 
                                                key={prank.id + idx}
                                                onClick={() => setViewingPrank(prank)} 
                                                className="w-full text-left p-2 hover:bg-white/5 rounded text-xs text-zinc-300 flex items-center gap-2 border border-zinc-800 hover:border-zinc-600 transition-colors"
                                             >
                                                 <span className="opacity-50 font-mono text-[9px]">{new Date(prank.timestamp).toLocaleDateString()}</span>
                                                 <span className="truncate">
                                                    {prank.type === 'emoji_rain' && '🌧 Emoji Rain'}
                                                    {prank.type === 'battery' && '⚡ Fake Battery'}
                                                    {prank.type === 'sticky_note' && '📝 Sticky Note'}
                                                    {prank.type === 'retro_popup' && '🪟 Retro Popup'}
                                                    {prank.type === 'breakup_letter' && '💔 Breakup Letter'}
                                                    {prank.type === 'gift_box' && '🎁 Gift Box'}
                                                    {prank.type === 'snapshot' && '📸 Snapshot'}
                                                    {prank.type === 'pitiful_popup' && '🥺 Pitiful Popup'}
                                                 </span>
                                             </button>
                                         ))}
                                     </div>
                                 </div>
                             )}
                          </>
                      )}
                  </div>
              </div>
          </div>
      )}

      {/* Special Events Display (Story) */}
      <SpecialEvents type={viewingArtifact} onClose={() => setViewingArtifact(null)} />
      
      {/* Echo Pranks Display (Archive View) */}
      <EchoPranks data={viewingPrank} onClose={() => setViewingPrank(null)} />

      {/* Settings Modal (Theme + World Book) */}
      {showThemeModal && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
            onClick={() => setShowThemeModal(false)}
          >
              <div 
                className="w-full max-w-sm bg-zinc-900/95 border border-zinc-700 rounded-xl p-6 shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]"
                onClick={(e) => e.stopPropagation()}
              >
                   {/* ... Settings Modal Content ... */}
                   <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
                   <h3 className="text-sm font-mono font-bold uppercase tracking-widest text-white mb-4 flex items-center gap-2 shrink-0">
                       <Icons.Settings />
                       <span>Chat_Config</span>
                   </h3>
                   <div className="space-y-4 overflow-y-auto flex-1 pr-1">
                       <div>
                           <label className="block text-xs text-zinc-500 uppercase font-bold mb-2 ml-1 flex items-center gap-1">
                               <Icons.Book />
                               <span>世界书绑定 (Context Link)</span>
                           </label>
                           <div className="space-y-3 bg-black/40 border border-zinc-700 rounded-lg p-3 max-h-64 overflow-y-auto">
                               {worldBooks.length === 0 && (
                                   <div className="text-xs text-zinc-600 text-center py-2">无可用世界书</div>
                               )}
                               {categories.length > 0 && (
                                   <div className="space-y-1">
                                       <div className="text-[10px] text-zinc-500 uppercase font-bold px-1">按分类绑定 (Categories)</div>
                                       {categories.map(cat => (
                                           <label key={cat} className="flex items-center p-2 rounded hover:bg-white/5 cursor-pointer bg-zinc-800/30">
                                               <div className={`w-4 h-4 rounded border flex items-center justify-center mr-3 transition-colors
                                                   ${boundCategories.includes(cat) ? 'bg-white border-white' : 'border-zinc-600'}`}>
                                                   {boundCategories.includes(cat) && <div className="text-black text-[10px]"><Icons.Check /></div>}
                                               </div>
                                               <input type="checkbox" className="hidden" checked={boundCategories.includes(cat)} onChange={() => toggleCategory(cat)} />
                                               <span className={`text-sm ${boundCategories.includes(cat) ? 'text-white' : 'text-zinc-400'}`}>{cat}</span>
                                           </label>
                                       ))}
                                   </div>
                               )}
                               {worldBooks.length > 0 && (
                                   <div className="space-y-1 pt-2">
                                       <div className="text-[10px] text-zinc-500 uppercase font-bold px-1">单本绑定 (Individuals)</div>
                                       {worldBooks.map(wb => (
                                           <label key={wb.id} className="flex items-center p-2 rounded hover:bg-white/5 cursor-pointer">
                                               <div className={`w-4 h-4 rounded border flex items-center justify-center mr-3 transition-colors
                                                   ${boundWorldBookIds.includes(wb.id) ? 'bg-white border-white' : 'border-zinc-600'}`}>
                                                   {boundWorldBookIds.includes(wb.id) && <div className="text-black text-[10px]"><Icons.Check /></div>}
                                               </div>
                                               <input type="checkbox" className="hidden" checked={boundWorldBookIds.includes(wb.id)} onChange={() => toggleWorldBook(wb.id)} />
                                               <div className="flex flex-col min-w-0">
                                                   <span className={`text-sm truncate ${boundWorldBookIds.includes(wb.id) ? 'text-white' : 'text-zinc-400'}`}>{wb.name}</span>
                                                   <span className="text-[9px] text-zinc-600">{wb.category || '未分类'}</span>
                                               </div>
                                           </label>
                                       ))}
                                   </div>
                               )}
                           </div>
                       </div>
                       <div className="h-px bg-white/5 my-4"></div>
                       <div>
                           <label className="block text-xs text-zinc-500 uppercase font-bold mb-1 ml-1">聊天背景 (URL)</label>
                           <input type="text" value={themeBg} onChange={(e) => setThemeBg(e.target.value)} placeholder="https://..." className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-white/50" />
                       </div>
                       <div>
                           <label className="block text-xs text-zinc-500 uppercase font-bold mb-1 ml-1">自定义气泡 CSS</label>
                           <textarea value={themeCss} onChange={(e) => setThemeCss(e.target.value)} rows={6} placeholder={`.custom-bubble-user { ... }`} className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-xs font-mono text-zinc-300 focus:outline-none focus:border-white/50 resize-none" />
                       </div>
                   </div>
                   <div className="mt-6 flex justify-end gap-2 shrink-0">
                       <button onClick={() => setShowThemeModal(false)} className="px-4 py-2 text-xs font-bold uppercase text-zinc-500 hover:text-white transition-colors">取消</button>
                       <button onClick={handleSaveTheme} className="px-4 py-2 bg-white text-black text-xs font-bold uppercase rounded hover:bg-zinc-200 transition-colors">应用</button>
                   </div>
              </div>
          </div>
      )}

      {/* Trace Modal / Overlay */}
      {showTraceModal && onlineStatus === 'offline' && !isLumiOffline && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in" onClick={() => setShowTraceModal(false)}>
              <div className="w-full max-w-md bg-zinc-900 border border-zinc-700 rounded-xl p-6 shadow-2xl relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
                  <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
                  <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center space-x-2 text-zinc-400 text-xs font-mono uppercase tracking-widest">
                          <span className="w-2 h-2 rounded-full bg-zinc-500 animate-pulse"></span>
                          <span>Target_Trace_Log</span>
                      </div>
                      <div className="flex items-center gap-2">
                           <button onClick={handleRefreshTrace} disabled={isTracingLoading} className={`text-zinc-500 hover:text-white transition-colors ${isTracingLoading ? 'animate-spin' : ''}`}><Icons.Refresh /></button>
                           <button onClick={() => setShowTraceModal(false)} className="text-zinc-500 hover:text-white"><Icons.X /></button>
                      </div>
                  </div>
                  <div className="mb-6 bg-black/40 rounded-lg p-4 min-h-[150px] max-h-[300px] overflow-y-auto border border-zinc-800/50">
                      {isTracingLoading ? (
                           <div className="flex flex-col items-center justify-center h-full space-y-3 opacity-50 py-8">
                               <div className="w-8 h-8 border-2 border-zinc-600 border-t-white rounded-full animate-spin"></div>
                               <span className="text-xs font-mono">定位追踪中 (ACQUIRING_TARGET)...</span>
                           </div>
                      ) : (
                          <div className="text-sm text-zinc-300 leading-relaxed font-sans whitespace-pre-wrap">{offlineActivity || "信号接收失败，请刷新重试..."}</div>
                      )}
                  </div>
                  <button onClick={handleSummonClick} disabled={isTracingLoading} className="w-full flex items-center justify-center space-x-2 bg-white text-black py-3 rounded-lg hover:bg-zinc-200 transition-colors text-xs font-bold uppercase disabled:opacity-50">
                      <Icons.Zap />
                      <span>强行召唤 (INTERRUPT)</span>
                  </button>
              </div>
          </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 relative z-0">
        {visibleMessages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-zinc-700 opacity-50">
             <div className="w-20 h-20 rounded-full bg-zinc-900 flex items-center justify-center mb-4 relative">
                <Icons.User />
                <div className={`absolute bottom-1 right-1 w-4 h-4 rounded-full border-4 border-black ${onlineStatus === 'online' ? 'bg-green-500' : 'bg-zinc-500'}`}></div>
             </div>
             <p className="text-sm font-mono text-zinc-400 drop-shadow-md">
                 {onlineStatus === 'online' ? "连接正常 (LINK_ESTABLISHED)" : "连接断开 (OFFLINE)"}
             </p>
          </div>
        )}

        {visibleMessages.map((msg: Message, index: number) => {
          const isUser = msg.role === 'user';
          const showAvatar = !isUser && (index === 0 || visibleMessages[index - 1].role === 'user');
          const isSelected = selectedMsgIds.has(msg.id);
          let showDate = false;
          if (index === 0) {
              showDate = true;
          } else {
              const prevMsg = visibleMessages[index - 1];
              const prevDate = new Date(prevMsg.timestamp);
              const currDate = new Date(msg.timestamp);
              if (prevDate.toDateString() !== currDate.toDateString()) {
                  showDate = true;
              }
          }

          return (
            <React.Fragment key={msg.id}>
                {showDate && (
                    <div className="flex justify-center my-6 select-none animate-fade-in">
                        <span className="text-[10px] font-mono tracking-wide text-zinc-500/80 bg-zinc-900/60 px-3 py-0.5 rounded-full border border-white/5 backdrop-blur-sm shadow-sm">
                            {formatDateSeparator(msg.timestamp)}
                        </span>
                    </div>
                )}
                <MessageBubble 
                    msg={msg}
                    character={activeCharacter}
                    isUser={isUser}
                    showAvatar={showAvatar}
                    activeMsgId={activeMsgId}
                    onMessageClick={handleMessageClick}
                    onCopy={handleCopyWrapper}
                    onQuote={handleQuoteMessage}
                    isDeleteMode={isDeleteMode}
                    isSelected={isSelected}
                />
            </React.Fragment>
          );
        })}
        {isLoading && (
           <div className="flex w-full justify-start animate-pulse">
              <div className="w-8 mr-2" />
              <div className="bg-zinc-800/50 border border-white/5 px-4 py-2 rounded-2xl rounded-bl-none backdrop-blur-sm">
                 <div className="flex space-x-1">
                    <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></div>
                    <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></div>
                    <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></div>
                 </div>
              </div>
           </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Sticker Picker Drawer */}
      {showStickerPicker && (
           <div className="border-t border-zinc-800 bg-zinc-900/90 backdrop-blur-md p-4 animate-slide-up z-20 h-48 overflow-y-auto">
               <div className="grid grid-cols-4 md:grid-cols-6 gap-3">
                   {stickers.map(s => (
                       <button 
                           key={s.id} 
                           onClick={() => handleSendSticker(s.url)}
                           className="aspect-square rounded-lg bg-black/40 border border-zinc-800 hover:border-zinc-500 hover:bg-black/60 transition-all flex items-center justify-center p-2 relative group"
                           title={s.keyword}
                       >
                           <img src={s.url} alt={s.keyword} className="w-full h-full object-contain" />
                           <span className="absolute bottom-0 text-[9px] bg-black/60 text-white px-1 opacity-0 group-hover:opacity-100 transition-opacity truncate max-w-full">{s.keyword}</span>
                       </button>
                   ))}
                   {stickers.length === 0 && (
                       <div className="col-span-full text-center text-zinc-500 text-xs py-10">
                           暂无表情包，请在侧边栏“表情包管理”中添加。
                       </div>
                   )}
               </div>
           </div>
      )}

      {/* Input Area */}
      <div className={`backdrop-blur-md border-t border-zinc-800 transition-all duration-300 relative z-10 ${isDeleteMode ? 'opacity-30 pointer-events-none grayscale' : 'bg-zinc-900/50'}`}>
          {/* Lumi Offline Note */}
          {isLumiOffline && (
              <div className="absolute top-0 left-0 right-0 -translate-y-full bg-yellow-900/20 border-t border-yellow-900/50 text-center py-1">
                  <div className="text-[10px] font-mono text-yellow-500 flex items-center justify-center gap-2">
                      <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full animate-pulse"></span>
                      SYSTEM_MAINTENANCE: REPLIES_DISABLED. MESSAGES WILL BE QUEUED.
                  </div>
              </div>
          )}

          {replyingTo && (
              <div className="max-w-4xl mx-auto px-4 md:px-6 pt-3 animate-slide-up">
                  <div className="flex justify-between items-center bg-zinc-800/60 border-l-4 border-white/40 rounded-r-lg p-3 backdrop-blur-sm shadow-lg">
                      <div className="flex flex-col overflow-hidden mr-4">
                          <span className="text-[10px] font-bold text-zinc-400 uppercase mb-0.5">
                              回复 {getSenderName(replyingTo)}
                          </span>
                          <span className="text-xs text-zinc-300 truncate font-mono opacity-80">
                              {replyingTo.content}
                          </span>
                      </div>
                      <button 
                          onClick={() => setReplyingTo(null)}
                          className="p-1 hover:bg-zinc-700 rounded text-zinc-500 hover:text-white transition-colors"
                      >
                          <Icons.X />
                      </button>
                  </div>
              </div>
          )}

          <div className="p-3 md:p-6 pb-safe">
              <div className="relative max-w-4xl mx-auto flex items-end gap-2 md:gap-3">
                  {/* Plus Button */}
                  <div className="relative flex-shrink-0 self-center">
                      <button
                          onClick={(e) => {
                              e.stopPropagation();
                              if (showPlusMenu) {
                                setShowPlusMenu(false);
                              } else {
                                setShowPlusMenu(true);
                                setShowStickerPicker(false);
                              }
                          }}
                          disabled={!activeCharacter || isDeleteMode}
                          className={`w-10 h-10 rounded-full border border-zinc-700 flex items-center justify-center transition-all
                              ${showPlusMenu ? 'bg-zinc-800 text-white rotate-45' : 'bg-black/40 text-zinc-400 hover:text-white hover:bg-zinc-800'}
                          `}
                      >
                          <Icons.Plus />
                      </button>
                      
                      {/* Plus Menu Popup */}
                      {showPlusMenu && (
                          <div className="absolute bottom-full left-0 mb-3 bg-zinc-900 border border-zinc-700 rounded-xl shadow-2xl p-2 min-w-[140px] animate-fade-in z-50 flex flex-col gap-1">
                               <button 
                                   onClick={handleToggleVoiceMode}
                                   className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-bold transition-colors w-full text-left
                                       ${isVoiceMode ? 'bg-white text-black' : 'text-zinc-300 hover:bg-white/10 hover:text-white'}
                                   `}
                               >
                                   <Icons.Mic />
                                   <span>{isVoiceMode ? '取消语音' : '语音'}</span>
                               </button>
                               <button 
                                   onClick={handleToggleStickerPicker}
                                   className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-bold transition-colors w-full text-left
                                       ${showStickerPicker ? 'bg-white text-black' : 'text-zinc-300 hover:bg-white/10 hover:text-white'}
                                   `}
                               >
                                   <Icons.Sticker />
                                   <span>表情包</span>
                               </button>
                          </div>
                      )}
                  </div>

                  <div className="relative flex-1">
                      <input
                      ref={inputRef}
                      type="text"
                      value={inputVal}
                      onChange={(e) => setInputVal(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                      placeholder={
                          replyingTo ? "回复..." : 
                          (isVoiceMode ? "输入内容以生成语音条..." : 
                          (isLumiOffline ? "维护模式：发送消息将保留至系统恢复" : 
                          (activeCharacter ? `发送给 ${activeCharacter.name}...` : "")))
                      }
                      disabled={!activeCharacter || isDeleteMode}
                      className={`w-full bg-black/60 border text-white rounded-2xl pl-4 pr-10 py-3 text-sm md:text-base focus:outline-none focus:bg-black/80 transition-all backdrop-blur-sm
                          ${isVoiceMode ? 'border-green-500/50 placeholder:text-green-500/50' : 'border-zinc-700 placeholder:text-zinc-500 focus:border-white/40'}
                          ${isLumiOffline ? 'border-yellow-900/50 placeholder:text-yellow-500/50' : ''}
                      `}
                      />
                      
                      {/* Mobile Send Button */}
                      <button 
                      onClick={handleSend}
                      disabled={!inputVal.trim() || isDeleteMode}
                      className={`absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full transition-all md:hidden disabled:opacity-50
                          ${isVoiceMode ? 'bg-green-500 text-black hover:bg-green-400' : 'bg-white text-black hover:bg-zinc-200'}
                      `}
                      >
                        {isVoiceMode ? (
                             <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
                        ) : (
                             <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                        )}
                      </button>

                      {/* Desktop Send Button */}
                      <button 
                      onClick={handleSend}
                      disabled={!inputVal.trim() || isDeleteMode}
                      className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full transition-all hidden md:block disabled:opacity-50
                          ${isVoiceMode ? 'bg-green-500 text-black hover:bg-green-400' : 'bg-white text-black hover:bg-zinc-200'}
                      `}
                      >
                       {isVoiceMode ? <Icons.Mic /> : <Icons.Send />}
                      </button>
                  </div>
                  
                  <button 
                  onClick={onTriggerAI}
                  disabled={isLoading || !activeCharacter || isDeleteMode || isLumiOffline}
                  className={`flex-shrink-0 w-12 h-12 md:w-12 md:h-12 rounded-full border flex items-center justify-center transition-all disabled:opacity-50 backdrop-blur-sm
                    ${onlineStatus === 'offline' 
                        ? 'bg-zinc-900/80 border-zinc-800 text-zinc-500 cursor-not-allowed hover:bg-zinc-800' 
                        : (isLumiOffline 
                            ? 'bg-yellow-900/20 border-yellow-900/50 text-yellow-500/50 cursor-not-allowed'
                            : 'bg-zinc-800/80 border-zinc-700 text-white hover:bg-zinc-700 hover:border-zinc-500')
                    }
                  `}
                  >
                  <Icons.Sparkles />
                  </button>
              </div>
          </div>
      </div>
    </div>
  );
};

export default ChatWindow;
