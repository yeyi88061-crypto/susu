import React, { useState, useEffect } from 'react';
import { Sticker } from '../types';
import { Icons } from './Icons';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  stickers: Sticker[];
  onSave: (stickers: Sticker[]) => void;
  onDelete: (id: string) => void;
}

const StickerModal: React.FC<Props> = ({ isOpen, onClose, stickers, onSave, onDelete }) => {
  const [activeTab, setActiveTab] = useState<'list' | 'import'>('list');
  const [importText, setImportText] = useState('');

  // Reset text when opening
  useEffect(() => {
    if (isOpen) {
      setImportText('');
      setActiveTab('list');
    }
  }, [isOpen]);

  const handleImport = () => {
    if (!importText.trim()) return;
    
    const lines = importText.split('\n');
    const newStickers: Sticker[] = [];
    
    lines.forEach(line => {
        if (!line.trim()) return;
        // Split by first comma or Chinese comma
        const parts = line.split(/,|，/);
        if (parts.length >= 2) {
            const keyword = parts[0].trim();
            // Join the rest in case URL has commas
            const url = parts.slice(1).join(',').trim();
            if (keyword && url) {
                newStickers.push({
                    id: Date.now().toString() + Math.random(),
                    keyword,
                    url
                });
            }
        }
    });

    if (newStickers.length > 0) {
        onSave(newStickers);
        setImportText('');
        setActiveTab('list');
        alert(`成功导入 ${newStickers.length} 个表情包`);
    } else {
        alert("格式不正确。请使用：提示词, URL (每行一个)");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl animate-fade-in relative flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between shrink-0">
             <h2 className="text-xl font-mono text-white tracking-wider flex items-center gap-2">
                 <Icons.Sticker />
                 <span>表情包管理 (STICKERS)</span>
             </h2>
             <button onClick={onClose} className="p-2 text-zinc-500 hover:text-white rounded-full hover:bg-white/10">
                <Icons.X />
             </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-zinc-800">
            <button 
                onClick={() => setActiveTab('list')}
                className={`flex-1 py-3 text-xs font-bold uppercase transition-colors
                ${activeTab === 'list' ? 'bg-zinc-800 text-white border-b-2 border-white' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
                已保存列表
            </button>
            <button 
                onClick={() => setActiveTab('import')}
                className={`flex-1 py-3 text-xs font-bold uppercase transition-colors
                ${activeTab === 'import' ? 'bg-zinc-800 text-white border-b-2 border-white' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
                批量导入
            </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden p-4">
            {activeTab === 'list' ? (
                <div className="h-full overflow-y-auto grid grid-cols-3 md:grid-cols-4 gap-4 content-start">
                    {stickers.length === 0 && (
                        <div className="col-span-full flex flex-col items-center justify-center text-zinc-600 mt-10">
                            <Icons.Image />
                            <p className="mt-2 text-xs">暂无表情包，请切换到“批量导入”添加</p>
                        </div>
                    )}
                    {stickers.map(s => (
                        <div key={s.id} className="relative group bg-zinc-950 rounded-lg border border-zinc-800 aspect-square flex flex-col items-center justify-center overflow-hidden">
                            <img src={s.url} alt={s.keyword} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                            <div className="absolute bottom-0 left-0 right-0 bg-black/80 text-[10px] text-center py-1 text-white truncate px-1">
                                {s.keyword}
                            </div>
                            <button 
                                onClick={() => onDelete(s.id)}
                                className="absolute top-1 right-1 p-1 bg-black/60 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
                            >
                                <Icons.X />
                            </button>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="h-full flex flex-col">
                    <div className="bg-zinc-800/50 p-3 rounded-lg mb-4 text-xs text-zinc-400 border border-zinc-700">
                        <p className="font-bold text-zinc-300 mb-1">格式说明：</p>
                        <p>每一行输入一个表情包，格式为：<span className="text-white font-mono">关键词, 图片链接</span></p>
                        <p className="mt-1 opacity-60">例如：<br/>开心, https://example.com/happy.png<br/>生气, https://example.com/angry.jpg</p>
                    </div>
                    <textarea 
                        value={importText}
                        onChange={(e) => setImportText(e.target.value)}
                        className="flex-1 w-full bg-black/40 border border-zinc-700 rounded-lg p-3 text-sm font-mono text-zinc-300 focus:outline-none focus:border-white/50 resize-none"
                        placeholder={`开心, https://...\n难过, https://...`}
                    />
                    <div className="mt-4 flex justify-end">
                        <button 
                            onClick={handleImport}
                            className="px-6 py-2 bg-white text-black text-xs font-bold uppercase rounded hover:bg-zinc-200 transition-colors"
                        >
                            开始导入
                        </button>
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default StickerModal;