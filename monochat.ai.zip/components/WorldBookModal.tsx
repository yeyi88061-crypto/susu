
import React, { useState, useEffect } from 'react';
import { WorldBook } from '../types';
import { Icons } from './Icons';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  worldBooks: WorldBook[];
  onSave: (wb: WorldBook) => void;
  onDelete: (id: string) => void;
}

const WorldBookModal: React.FC<Props> = ({ isOpen, onClose, worldBooks, onSave, onDelete }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formContent, setFormContent] = useState('');

  // Reset form when opening or switching selection
  useEffect(() => {
    if (!isOpen) {
      setEditingId(null);
      setFormName('');
      setFormCategory('');
      setFormContent('');
    }
  }, [isOpen]);

  const handleSelect = (wb: WorldBook) => {
    setEditingId(wb.id);
    setFormName(wb.name);
    setFormCategory(wb.category || '');
    setFormContent(wb.content);
  };

  const handleCreateNew = () => {
    setEditingId('new');
    setFormName('');
    setFormCategory('');
    setFormContent('');
  };

  const handleSaveAction = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!formName.trim()) {
        alert("请输入世界书名称");
        return;
    }
    const id = editingId === 'new' ? Date.now().toString() : editingId!;
    onSave({
        id,
        name: formName,
        category: formCategory.trim() || '未分类',
        content: formContent
    });
    if (editingId === 'new') {
        setEditingId(id); 
    }
  };

  const handleDeleteAction = (id: string) => {
      if (confirm('确定要销毁这本世界书吗？此操作不可逆。')) {
          onDelete(id);
          if (editingId === id) {
              setEditingId(null);
              setFormName('');
              setFormCategory('');
              setFormContent('');
          }
      }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-4xl h-[85vh] bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl animate-fade-in relative flex overflow-hidden flex-col md:flex-row">
        
        {/* Decorative glass glare */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent z-10"></div>

        {/* --- LEFT SIDE: LIST --- */}
        <div className={`
            flex-col bg-black/20 md:border-r border-zinc-800 h-full
            ${editingId ? 'hidden md:flex md:w-1/3' : 'flex w-full md:w-1/3'}
        `}>
            <div className="p-4 border-b border-zinc-800 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2 text-white font-mono tracking-wider">
                    <Icons.Book />
                    <span className="font-bold">ARCHIVE</span>
                </div>
                <button onClick={onClose} className="p-2 text-zinc-500 hover:text-white rounded-full hover:bg-white/10">
                    <Icons.X />
                </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
                <button 
                    onClick={handleCreateNew}
                    className={`w-full text-left px-3 py-3 rounded-lg flex items-center gap-2 transition-colors mb-2 border border-dashed border-zinc-700 hover:border-zinc-500 text-zinc-400 hover:text-white
                    ${editingId === 'new' ? 'bg-zinc-800 border-solid border-zinc-600 text-white' : ''}`}
                >
                    <Icons.Plus />
                    <span className="text-xs font-bold uppercase">新建记录 (NEW ENTRY)</span>
                </button>

                {worldBooks.map(wb => (
                    <div 
                        key={wb.id} 
                        onClick={() => handleSelect(wb)}
                        className={`group flex flex-col justify-center px-3 py-3 rounded-lg cursor-pointer transition-all border border-transparent
                        ${editingId === wb.id ? 'bg-white/10 border-white/10 text-white' : 'hover:bg-white/5 text-zinc-400'}`}
                    >
                        <div className="flex justify-between items-center w-full">
                            <span className="truncate text-sm font-medium">{wb.name}</span>
                            <button 
                                onClick={(e) => { e.stopPropagation(); handleDeleteAction(wb.id); }}
                                className="p-1 text-zinc-500 hover:text-red-400 transition-opacity md:opacity-0 md:group-hover:opacity-100"
                            >
                                <Icons.Trash />
                            </button>
                        </div>
                        <div className="text-[10px] opacity-50 uppercase font-mono mt-0.5 flex items-center gap-1">
                             <span className="w-1.5 h-1.5 rounded-full bg-zinc-600"></span>
                             {wb.category || 'Uncategorized'}
                        </div>
                    </div>
                ))}
                
                {worldBooks.length === 0 && editingId !== 'new' && (
                    <div className="text-center text-zinc-600 text-xs mt-10">
                        暂无数据记录
                    </div>
                )}
            </div>
        </div>

        {/* --- RIGHT SIDE: EDITOR --- */}
        <div className={`
            flex-col bg-zinc-900/50 h-full
            ${editingId ? 'flex w-full md:flex-1' : 'hidden md:flex md:flex-1'}
        `}>
             {editingId ? (
                 <>
                    <div className="p-4 border-b border-zinc-800 flex flex-col gap-4 shrink-0">
                        {/* Header Row: Back/Title/Actions */}
                        <div className="flex justify-between items-center w-full gap-2">
                             <div className="flex items-center gap-2 flex-1 min-w-0">
                                <button 
                                    onClick={() => setEditingId(null)} 
                                    className="md:hidden p-1 mr-1 text-zinc-400 hover:text-white"
                                >
                                    <Icons.ChevronLeft />
                                </button>
                                <input 
                                    type="text" 
                                    value={formName}
                                    onChange={(e) => setFormName(e.target.value)}
                                    placeholder="世界书名称..."
                                    className="bg-transparent text-lg font-bold text-white placeholder-zinc-600 focus:outline-none flex-1 min-w-0"
                                />
                             </div>
                             <div className="flex items-center gap-2 shrink-0">
                                 <button 
                                    onClick={handleSaveAction}
                                    className="px-4 py-1.5 bg-white text-black text-xs font-bold uppercase rounded hover:bg-zinc-200 transition-colors whitespace-nowrap"
                                >
                                    保存
                                </button>
                                <button onClick={() => setEditingId(null)} className="hidden md:block p-2 text-zinc-500 hover:text-white">
                                    <Icons.X />
                                </button>
                                <button onClick={onClose} className="md:hidden p-2 text-zinc-500 hover:text-white">
                                    <Icons.X />
                                </button>
                             </div>
                        </div>
                        
                        {/* Category Input */}
                        <div className="flex items-center gap-2 bg-black/20 p-2 rounded-lg border border-zinc-800">
                             <span className="text-xs font-bold text-zinc-500 uppercase px-2">分类</span>
                             <div className="h-4 w-px bg-zinc-700"></div>
                             <input 
                                type="text"
                                value={formCategory}
                                onChange={(e) => setFormCategory(e.target.value)}
                                placeholder="例如: 赛博朋克 / 魔法 / 日常"
                                className="bg-transparent text-xs text-zinc-300 focus:outline-none w-full"
                                list="category-suggestions"
                             />
                             <datalist id="category-suggestions">
                                 {Array.from(new Set(worldBooks.map(wb => wb.category).filter(Boolean))).map(c => (
                                     <option key={c} value={c} />
                                 ))}
                             </datalist>
                        </div>
                    </div>
                    
                    <div className="flex-1 p-4 flex flex-col min-h-0">
                        <textarea 
                            value={formContent}
                            onChange={(e) => setFormContent(e.target.value)}
                            className="flex-1 w-full bg-black/20 text-zinc-300 text-sm font-mono leading-relaxed p-4 rounded-lg border border-zinc-800 focus:border-zinc-600 focus:outline-none resize-none"
                            placeholder={`在此输入世界书内容...`}
                        />
                        <div className="mt-2 text-[10px] text-zinc-500 font-mono shrink-0">
                            TIPS: 这里的分类用于方便您在聊天中快速绑定一组世界书。
                        </div>
                    </div>
                 </>
             ) : (
                 <div className="flex-1 flex-col items-center justify-center text-zinc-600 hidden md:flex">
                     <div className="w-16 h-16 rounded-full bg-zinc-800/50 flex items-center justify-center mb-4">
                         <Icons.Book />
                     </div>
                     <p className="text-sm font-mono">请选择或新建一个世界书条目</p>
                 </div>
             )}
        </div>

      </div>
    </div>
  );
};

export default WorldBookModal;
