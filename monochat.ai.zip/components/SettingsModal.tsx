
import React, { useState, useEffect } from 'react';
import { AppSettings } from '../types';
import { fetchModels, normalizeUrl } from '../services/chatService';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSave: (s: AppSettings) => void;
}

const SettingsModal: React.FC<Props> = ({ isOpen, onClose, settings, onSave }) => {
  const [formData, setFormData] = useState<AppSettings>(settings);
  const [availableModels, setAvailableModels] = useState<string[]>([]);
  const [loadingModels, setLoadingModels] = useState(false);
  const [detectedType, setDetectedType] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setFormData(settings);
      setDetectedType(settings.apiType || null);
    }
  }, [isOpen, settings]);

  const handleFetchModels = async () => {
    setLoadingModels(true);
    setDetectedType(null);
    try {
        const result = await fetchModels(formData);
        setAvailableModels(result.models);
        setDetectedType(result.apiType);
        // Update the form data with the detected type
        setFormData(prev => ({ ...prev, apiType: result.apiType }));
    } catch (e) {
        alert(e instanceof Error ? e.message : '获取模型列表失败');
    } finally {
        setLoadingModels(false);
    }
  };

  const handleChange = (field: keyof AppSettings, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleUrlBlur = () => {
    const normalized = normalizeUrl(formData.apiUrl);
    if (normalized !== formData.apiUrl) {
      handleChange('apiUrl', normalized);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-2xl animate-fade-in relative overflow-hidden">
        {/* Decorative glass glare */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
        
        <h2 className="text-xl font-mono mb-6 text-white tracking-wider">系统配置 (SYSTEM_CONFIG)</h2>

        <div className="space-y-4">
          
          {/* API URL */}
          <div>
            <label className="block text-xs text-zinc-500 uppercase font-bold mb-1 ml-1">API 基础地址 (Base URL)</label>
            <input 
              type="text" 
              value={formData.apiUrl}
              onChange={(e) => handleChange('apiUrl', e.target.value)}
              onBlur={handleUrlBlur}
              placeholder="https://generativelanguage.googleapis.com"
              className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-white/50 transition-colors"
            />
            <p className="text-[10px] text-zinc-600 mt-1 ml-1">
                支持 Gemini (Google) 和 OpenAI 格式 (例如 OneAPI)。
            </p>
          </div>

          {/* API Key */}
          <div>
            <label className="block text-xs text-zinc-500 uppercase font-bold mb-1 ml-1">API 密钥 (Key)</label>
            <input 
              type="password" 
              value={formData.apiKey}
              onChange={(e) => handleChange('apiKey', e.target.value)}
              placeholder="请输入您的 API Key"
              className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-white/50 transition-colors"
            />
          </div>

          {/* Model Selection */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-xs text-zinc-500 uppercase font-bold ml-1">
                  模型选择 (Model) 
                  {detectedType && <span className="ml-2 px-1.5 py-0.5 rounded bg-white/20 text-white text-[10px]">{detectedType.toUpperCase()} MODE</span>}
              </label>
              <button 
                onClick={handleFetchModels}
                disabled={!formData.apiKey || loadingModels}
                className="text-[10px] uppercase font-bold text-white hover:text-zinc-300 disabled:opacity-30"
              >
                {loadingModels ? '连接中...' : '连接并获取模型'}
              </button>
            </div>
            {availableModels.length > 0 ? (
              <select 
                value={formData.selectedModel}
                onChange={(e) => handleChange('selectedModel', e.target.value)}
                className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-white/50"
              >
                {availableModels.map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            ) : (
                <input 
                type="text" 
                value={formData.selectedModel}
                onChange={(e) => handleChange('selectedModel', e.target.value)}
                placeholder="例如: gemini-1.5-flash 或 gpt-4o"
                className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-white/50 transition-colors"
              />
            )}
          </div>

          {/* Temperature Slider */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-xs text-zinc-500 uppercase font-bold ml-1">
                  创意温度 (Temperature): <span className="text-white font-mono">{formData.temperature ?? 1.0}</span>
              </label>
            </div>
            <input 
                type="range" 
                min="0" 
                max="2" 
                step="0.1"
                value={formData.temperature ?? 1.0} 
                onChange={(e) => handleChange('temperature', parseFloat(e.target.value))}
                className="w-full h-1.5 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-white hover:accent-zinc-300"
            />
            <div className="flex justify-between text-[9px] text-zinc-600 mt-1 px-1 font-mono">
                <span>精确 (0.0)</span>
                <span>平衡 (1.0)</span>
                <span>发散 (2.0)</span>
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-end space-x-3">
          <button 
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold uppercase text-zinc-500 hover:text-white transition-colors"
          >
            取消
          </button>
          <button 
            onClick={() => onSave(formData)}
            className="px-6 py-2 bg-white text-black text-xs font-bold uppercase rounded hover:bg-zinc-200 transition-colors"
          >
            保存配置
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
