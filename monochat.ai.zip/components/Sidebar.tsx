
import React from 'react';
import { Character } from '../types';
import { Icons } from './Icons';

interface Props {
  isOpen: boolean; // Mobile open state
  onClose: () => void; // Mobile close handler
  characters: Character[];
  activeCharId: string | null;
  onSelectChar: (id: string) => void;
  onEditChar: (char: Character) => void;
  onAddChar: () => void;
  onOpenSettings: () => void;
  onOpenWorldBooks: () => void;
  onOpenStickers: () => void;
}

const Sidebar: React.FC<Props> = ({
  isOpen,
  onClose,
  characters,
  activeCharId,
  onSelectChar,
  onEditChar,
  onAddChar,
  onOpenSettings,
  onOpenWorldBooks,
  onOpenStickers
}) => {
  
  return (
    <div 
        className={`
            fixed inset-y-0 left-0 z-40 w-80 h-full border-r border-zinc-800 
            bg-zinc-950/95 md:bg-zinc-900/30 backdrop-blur-xl md:backdrop-filter-none md:frosted-glass 
            transition-transform duration-300 ease-in-out md:relative md:translate-x-0 flex flex-col
            ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
    >
      <div className="p-6 border-b border-zinc-800 flex justify-between items-center shrink-0">
        <h1 className="text-xl font-mono tracking-widest font-bold text-white">MONO.CHAT</h1>
        <div className="flex items-center gap-1">
            <button onClick={onOpenStickers} className="p-2 hover:bg-white/10 rounded-full transition-colors text-zinc-400 hover:text-white" title="表情包管理">
            <Icons.Sticker />
            </button>
            <button onClick={onOpenWorldBooks} className="p-2 hover:bg-white/10 rounded-full transition-colors text-zinc-400 hover:text-white" title="世界书管理">
            <Icons.Book />
            </button>
            <button onClick={onOpenSettings} className="p-2 hover:bg-white/10 rounded-full transition-colors text-zinc-400 hover:text-white" title="全局设置">
            <Icons.Settings />
            </button>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-zinc-400 hover:text-white md:hidden">
            <Icons.X />
            </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        <div className="text-xs font-bold text-zinc-600 uppercase mb-2 px-2">聊天对象</div>
        {characters.map(char => (
          <div 
            key={char.id}
            className={`group flex items-center rounded-xl transition-all duration-300 border border-transparent ${activeCharId === char.id ? 'bg-white/10 border-white/10 shadow-lg' : 'hover:bg-white/5'}`}
          >
            {/* Clickable Area for Selection */}
            <div 
                className="flex-1 flex items-center p-3 cursor-pointer min-w-0"
                onClick={() => onSelectChar(char.id)}
            >
                <img src={char.avatar} alt={char.name} className="w-10 h-10 rounded-full object-cover bg-zinc-800" />
                <div className="ml-3 flex-1 min-w-0">
                  <div className="text-sm font-bold text-zinc-200 truncate">{char.name}</div>
                  <div className="text-xs text-zinc-500 truncate">{char.remark}</div>
                </div>
            </div>

            {/* Actions: Settings Button Only - Moved delete to inside the modal */}
            <div 
                className="flex items-center gap-1 pr-2 relative z-10"
                onClick={(e) => e.stopPropagation()}
            >
               <button 
                type="button"
                onClick={(e) => { e.stopPropagation(); onEditChar(char); }}
                className="p-2 text-zinc-500 hover:text-white hover:bg-white/10 rounded-full transition-colors"
                title="设置"
               >
                   <Icons.Settings />
               </button>
            </div>
          </div>
        ))}
        
        <button 
          onClick={onAddChar}
          className="w-full py-3 flex items-center justify-center space-x-2 border border-dashed border-zinc-800 rounded-xl text-zinc-500 hover:border-zinc-600 hover:text-zinc-300 transition-all mt-4"
        >
          <Icons.Plus />
          <span className="text-xs font-bold uppercase">添加对象</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
