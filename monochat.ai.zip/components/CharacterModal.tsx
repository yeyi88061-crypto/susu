
import React, { useState, useEffect } from 'react';
import { Character } from '../types';
import { db } from '../db';
import { Icons } from './Icons';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  character?: Character;
  onSave: (c: Character) => void;
  onDelete?: (id: string) => void; // Added onDelete prop
}

const CharacterModal: React.FC<Props> = ({ isOpen, onClose, character, onSave, onDelete }) => {
  const [formData, setFormData] = useState<Character>({
    id: '',
    name: '',
    avatar: '',
    remark: '',
    personality: '',
  });

  const [stats, setStats] = useState<{count: number, days: number} | null>(null);

  useEffect(() => {
    if (isOpen) {
      if (character) {
        setFormData(character);
        // Fetch stats
        db.getCharacterStats(character.id).then(res => {
            let realCount = 0;
            let realDays = 0;

            if (res.startTime > 0) {
                const diffTime = Math.abs(Date.now() - res.startTime);
                realDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                realCount = res.count;
            }
            
            setStats({ count: realCount, days: realDays });
        });
      } else {
        setFormData({
          id: Date.now().toString(),
          name: '',
          avatar: `https://picsum.photos/seed/${Date.now()}/200`,
          remark: '',
          personality: '',
        });
        setStats(null);
      }
    }
  }, [isOpen, character]);

  const handleChange = (field: keyof Character, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleMetadataChange = (field: 'manual_message_count' | 'manual_days', value: string) => {
      const numValue = value === '' ? undefined : parseInt(value, 10);
      setFormData(prev => ({
          ...prev,
          metadata: {
              ...prev.metadata,
              [field]: numValue
          }
      }));
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation(); // Stop event bubbling
    if (!formData.id || !onDelete) return;
    
    if (window.confirm(`确定要删除好友 "${formData.name}" 吗？\n\n警告：此操作不可恢复，所有聊天记录将被清空。`)) {
        onDelete(formData.id);
    }
  };
  
  const isLocked = formData.id === 'default_ai' || formData.id === 'lumi_ai';

  if (!isOpen) return null;

  // Determine displayed values (Manual Override > DB Stats)
  const displayCount = formData.metadata?.manual_message_count ?? stats?.count ?? 0;
  const displayDays = formData.metadata?.manual_days ?? stats?.days ?? 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4" onClick={(e) => e.stopPropagation()}>
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-2xl animate-fade-in relative">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
        <h2 className="text-xl font-mono mb-6 text-white tracking-wider">{character ? '编辑实体 (EDIT_ENTITY)' : '新建实体 (NEW_ENTITY)'}</h2>

        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <img src={formData.avatar} alt="预览" className="w-16 h-16 rounded-full border border-zinc-700 bg-zinc-800 object-cover" />
            <div className="flex-1">
              <label className="block text-xs text-zinc-500 uppercase font-bold mb-1 ml-1">头像 URL</label>
              <input 
                type="text" 
                value={formData.avatar}
                onChange={(e) => handleChange('avatar', e.target.value)}
                className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-white/50"
              />
            </div>
          </div>

          {/* Statistics Bar (Editable for Debug) */}
          {character && stats && (
              <div className="flex items-center gap-4 bg-zinc-800/50 p-2 rounded-lg border border-zinc-700/50 relative group">
                  <div className="absolute -top-2 right-0 bg-zinc-800 text-[9px] px-1.5 rounded border border-zinc-700 text-zinc-500 opacity-0 group-hover:opacity-100 transition-opacity">
                      TESTING_MODE: EDITABLE
                  </div>
                  <div className="flex-1 text-center border-r border-zinc-700">
                      <div className="text-[10px] text-zinc-500 uppercase font-bold mb-1">聊天条数 (COUNT)</div>
                      <input 
                        type="number"
                        value={displayCount}
                        onChange={(e) => handleMetadataChange('manual_message_count', e.target.value)}
                        className="w-full bg-transparent text-center text-sm font-mono text-white focus:outline-none focus:bg-white/5 rounded"
                      />
                  </div>
                  <div className="flex-1 text-center">
                      <div className="text-[10px] text-zinc-500 uppercase font-bold mb-1">相识天数 (DAYS)</div>
                      <div className="flex items-center justify-center gap-1">
                        <input 
                            type="number"
                            value={displayDays}
                            onChange={(e) => handleMetadataChange('manual_days', e.target.value)}
                            className="w-16 bg-transparent text-center text-sm font-mono text-white focus:outline-none focus:bg-white/5 rounded"
                        />
                        <span className="text-xs text-zinc-500">天</span>
                      </div>
                  </div>
              </div>
          )}

          <div>
            <label className="block text-xs text-zinc-500 uppercase font-bold mb-1 ml-1">名称</label>
            <input 
              type="text" 
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-white/50"
            />
          </div>

          <div>
            <label className="block text-xs text-zinc-500 uppercase font-bold mb-1 ml-1">备注 / 称号</label>
            <input 
              type="text" 
              value={formData.remark}
              onChange={(e) => handleChange('remark', e.target.value)}
              placeholder="例如：我的编程助手"
              className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-white/50"
            />
          </div>

          <div>
            <label className="block text-xs text-zinc-500 uppercase font-bold mb-1 ml-1">
                性格设定 (提示词)
                {isLocked && <span className="ml-2 text-[10px] text-red-400 bg-red-900/20 px-1 rounded border border-red-900/50">LOCKED</span>}
            </label>
            {isLocked ? (
                <div className="w-full h-32 bg-black/40 border border-red-900/30 border-dashed rounded-lg px-3 py-2 flex flex-col items-center justify-center text-red-500/50">
                    <span className="font-mono text-xl animate-pulse">ACCESS DENIED</span>
                    <span className="text-[10px]">ENCRYPTED DATA SEGMENT</span>
                </div>
            ) : (
                <textarea 
                value={formData.personality}
                onChange={(e) => handleChange('personality', e.target.value)}
                rows={4}
                placeholder="定义该实体的说话方式、行为逻辑和人设..."
                className="w-full bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:border-white/50 resize-none"
                />
            )}
          </div>
        </div>

        <div className="mt-8 flex justify-between items-center">
            {/* Delete Button (Left Aligned) - Hidden for System/New characters */}
            <div>
              {character && !isLocked && onDelete && (
                <button 
                  type="button"
                  onClick={handleDelete}
                  className="px-4 py-2 text-xs font-bold uppercase text-red-500 hover:text-red-400 hover:bg-red-900/20 rounded transition-colors flex items-center gap-2 group"
                  title="删除好友"
                >
                    <Icons.Trash />
                    <span className="group-hover:underline underline-offset-4">删除好友</span>
                </button>
              )}
            </div>
            
            {/* Action Buttons (Right Aligned) */}
            <div className="flex space-x-3">
                <button onClick={onClose} className="px-4 py-2 text-xs font-bold uppercase text-zinc-500 hover:text-white transition-colors">取消</button>
                <button onClick={() => onSave(formData)} className="px-6 py-2 bg-white text-black text-xs font-bold uppercase rounded hover:bg-zinc-200 transition-colors">保存实体</button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default CharacterModal;
