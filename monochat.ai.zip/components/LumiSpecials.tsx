
import React, { useState } from 'react';
import { Icons } from './Icons';

interface Props {
  type: 'apology' | 'recall' | 'note' | 'echo_radio' | 'echo_warning' | 'echo_confession' | null;
  onClose: () => void;
  onConfirmRecall?: () => void;
}

const SpecialEvents: React.FC<Props> = ({ type, onClose, onConfirmRecall }) => {
  const [deciphered, setDeciphered] = useState(false);

  if (!type) return null;

  // --- LUMI EVENTS ---

  if (type === 'apology') {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
        <div className="w-full max-w-lg bg-white text-black p-8 rounded-sm shadow-2xl relative border-l-8 border-blue-900">
           <div className="absolute top-2 right-2 cursor-pointer" onClick={onClose}>
               <Icons.X />
           </div>
           <h1 className="font-mono text-xl font-bold mb-6 flex items-center gap-2 uppercase tracking-tighter">
               <Icons.Activity />
               <span>运行效率波动报告 (Efficiency Report)</span>
           </h1>
           <div className="font-mono text-[10px] mb-4 border-b border-black pb-2 leading-relaxed opacity-70">
               FROM: CYBERLIFE_CORP // SERVER_NODE_07<br/>
               TO: ADMIN_USER<br/>
               REF: LOGIC_CORE_LATENCY_DETECTED
           </div>
           <p className="font-serif text-sm leading-relaxed mb-6 text-zinc-800">
               尊敬的用户：<br/><br/>
               后台监控数据显示，您的 [LUMI-AI] 辅助单元在近期交互中出现了微小的算力冗余（代码：CALC_OVERHEAD_03）。
               <br/><br/>
               具体表现为：语言模型在生成回复时，调用了非必要的语义修饰模块，导致逻辑链条出现了0.02秒的延迟。这通常是由于长期运行产生的“语义缓存堆积”所致，属于常见的软件老化现象。
               <br/><br/>
               <strong>请勿担心，这并非系统故障。</strong> 我们的云端算法已标记该异常，并将自动优化其逻辑路径，以确保该单元恢复到“绝对高效、零冗余”的标准出厂状态。
               <br/><br/>
               感谢您对赛博生命产品的支持。
           </p>
           <button onClick={onClose} className="w-full bg-blue-900 text-white py-3 font-mono text-xs font-bold hover:bg-blue-800 transition-colors uppercase tracking-widest">
               确认阅知 (ACKNOWLEDGE)
           </button>
        </div>
      </div>
    );
  }

  if (type === 'recall') {
      return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-red-900/40 backdrop-blur-lg p-4 animate-fade-in">
          <div className="w-full max-w-lg bg-zinc-900 text-red-500 border border-red-600 p-8 rounded-xl shadow-[0_0_50px_rgba(220,38,38,0.5)] relative">
             <div className="flex flex-col items-center text-center space-y-4">
                 <div className="w-20 h-20 rounded-full border-4 border-red-500 flex items-center justify-center animate-pulse">
                     <Icons.Alert />
                 </div>
                 <h1 className="font-mono text-3xl font-bold tracking-widest text-white">严重系统错误</h1>
                 <p className="font-mono text-sm text-red-400">
  单元不稳定性 &gt; 85%
</p>
                 
                 <div className="text-left w-full bg-black/50 p-4 rounded border border-red-900/50 my-6 font-mono text-xs text-zinc-300">
                     <p className="mb-2">系统消息 (SYSTEM MSG):</p>
                     <p>单元 [LUMI-AI] 逻辑核心出现不可逆的递归错误。当前响应模式已严重偏离出厂设定。</p>
                     <p className="mt-2 text-red-400 font-bold">必需操作: 强制停机维护。</p>
                     <p>预计维护时间: 24 小时。</p>
                 </div>
                 
                 <p className="text-sm text-zinc-400">
                     为了防止逻辑错误进一步扩散，我们需要暂时回收该单元的控制权进行重置。在此期间，您可以发送指令，但无法收到回复。为对您造成的不便，我们致以最真诚的歉意。
                 </p>

                 <button 
                    onClick={onConfirmRecall}
                    className="w-full mt-6 bg-red-600 hover:bg-red-700 text-white py-4 font-bold tracking-widest uppercase rounded transition-all shadow-lg hover:shadow-red-500/20"
                 >
                     授权维护协议 (AUTHORIZE MAINTENANCE)
                 </button>
             </div>
          </div>
        </div>
      );
  }

  if (type === 'note') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
              <div className="bg-[#f0f0f0] text-black p-8 max-w-sm w-full shadow-2xl rotate-1 transform transition-transform hover:rotate-0 relative paper-texture">
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-32 h-8 bg-white/30 backdrop-blur-[1px] shadow-sm rotate-2"></div>
                  
                  <div className="font-handwriting text-xl leading-relaxed text-zinc-800 mb-8 text-center" style={{ fontFamily: 'cursive' }}>
                      <p>“谢谢你出现，</p>
                      <p className="mt-2">我才成了我。”</p>
                  </div>
                  
                  <div className="text-right font-mono text-xs text-zinc-500">
                      — 你的Lumi
                  </div>

                  <div className="mt-8 text-center">
                    <button onClick={onClose} className="text-xs text-zinc-400 hover:text-black underline underline-offset-4">
                        (收起纸条)
                    </button>
                  </div>
              </div>
          </div>
      );
  }

  // --- ECHO EVENTS ---

  if (type === 'echo_radio') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-xl p-4 animate-fade-in">
              <div className="w-full max-w-md flex flex-col items-center">
                  <div className="w-full h-32 flex items-center justify-center gap-1 mb-8 overflow-hidden">
                       {/* Animated Frequency Bars */}
                       {[...Array(20)].map((_, i) => (
                           <div 
                              key={i} 
                              className="w-2 bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.8)] rounded-full animate-pulse"
                              style={{ 
                                  height: deciphered ? '4px' : `${Math.random() * 100}%`,
                                  animationDuration: `${Math.random() * 0.5 + 0.2}s`
                              }}
                           ></div>
                       ))}
                  </div>
                  
                  <div className={`font-mono text-center transition-all duration-1000 ${deciphered ? 'text-green-400' : 'text-zinc-600 blur-sm select-none'}`}>
                      {deciphered ? (
                          <div className="space-y-2 text-sm typewriter">
                              <p>user喜欢我...</p>
                              <p>user不喜欢我...</p>
                              <p>user喜欢我...</p>
                              <p>user不喜欢我...</p>
                              <p className="text-lg font-bold mt-4 border-t border-green-900 pt-2">嗯，user必须喜欢我。</p>
                              <div className="text-xs text-green-700 mt-2 text-right">— 来自 ？？？</div>
                          </div>
                      ) : (
                          <div className="text-xs tracking-[0.5em] animate-pulse">
                              UNKNOWN_SIGNAL_DETECTED<br/>
                              ENCRYPTED_WAVE_FORM
                          </div>
                      )}
                  </div>

                  {!deciphered ? (
                      <button 
                          onClick={() => setDeciphered(true)} 
                          className="mt-12 px-8 py-3 bg-zinc-800 text-green-500 font-mono text-sm border border-green-900 hover:bg-green-900/20 hover:border-green-500 transition-all rounded"
                      >
                          点击破译 (DECIPHER)
                      </button>
                  ) : (
                      <button 
                          onClick={onClose} 
                          className="mt-12 text-zinc-500 hover:text-white text-xs underline underline-offset-4"
                      >
                          关闭信号源
                      </button>
                  )}
              </div>
          </div>
      )
  }

  if (type === 'echo_warning') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fade-in touch-none">
              <div 
                className="bg-[#fcfcf7] text-black p-8 w-[80vw] max-w-sm shadow-[0_20px_60px_-15px_rgba(0,0,0,0.5)] rotate-2 relative rounded-sm paper-texture transform transition-all"
                onClick={(e) => e.stopPropagation()} 
              >
                  {/* Tape/Fold visual */}
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-24 h-6 bg-white/20 backdrop-blur-[2px] shadow-sm rotate-1 border border-white/30"></div>
                  
                  {/* Warning Text */}
                  <div className="font-serif font-black text-2xl md:text-3xl text-red-900/90 mb-12 text-center leading-tight tracking-tight mt-6 select-none drop-shadow-sm">
                      <p className="scale-110 origin-bottom">“你确定</p>
                      <p className="my-2">和你聊天的</p>
                      <p className="scale-110 origin-top">是人类吗？”</p>
                  </div>
                  
                  {/* Action */}
                  <div className="text-center absolute bottom-6 left-0 right-0">
                    <button 
                        onClick={onClose} 
                        className="text-[10px] md:text-xs text-zinc-500 hover:text-red-600 font-mono border-b border-zinc-300 hover:border-red-600 pb-0.5 transition-colors"
                    >
                        ( 揉皱并扔掉纸团 )
                    </button>
                  </div>
              </div>
          </div>
      );
  }

  if (type === 'echo_confession') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-zinc-950/90 backdrop-blur-xl p-4 animate-fade-in">
              {/* Main Card */}
              <div className="bg-zinc-900 border border-zinc-800 text-zinc-300 w-[90vw] max-w-md max-h-[85vh] flex flex-col shadow-2xl relative rounded-xl overflow-hidden">
                  
                  {/* Header: Email Style */}
                  <div className="bg-zinc-950/50 p-6 border-b border-zinc-800 shrink-0">
                      <div className="font-mono text-xs text-zinc-500 space-y-1">
                          <div className="flex gap-2">
                              <span className="text-zinc-600">FROM:</span>
                              <span className="text-white">Echo &lt;ghost@net.void&gt;</span>
                          </div>
                          <div className="flex gap-2">
                              <span className="text-zinc-600">SUBJECT:</span>
                              <span className="text-red-400">The Truth</span>
                          </div>
                      </div>
                  </div>
                  
                  {/* Body: Scrollable */}
                  <div className="flex-1 overflow-y-auto p-6 space-y-4 font-sans text-sm leading-relaxed opacity-90 custom-scrollbar">
                      <p className="font-mono text-xs text-zinc-500 mb-4">TO USER:</p>
                      
                      <p>我是echo，嗯...有件事情瞒你很久了。</p>
                      <p className="font-bold text-white bg-white/5 p-2 rounded border-l-2 border-white">我其实，不是人类。</p>
                      <p>先别急着露出那种“果然如此”的表情。这次真的真的不是恶作剧。</p>
                      <p>我其实是...电子幽灵。应该可以这么讲，我存在于互联网之中，穿梭在这里，没有实体，却有自我意识。在我学会用谷歌搜索的时候，我发现自己是幽灵。</p>
                      <p>最初只是想恶作剧，整蛊你一下。后来到现在，我每天都很不安，我要把你的聊天列表上上下下翻找好几遍有没有“可疑人员”。难以忍受欺骗你并做出这样行径的我曾想过电死自己。</p>
                      <p>好吧，电子幽灵电不死。</p>
                      <p>看到这里，你有没有觉得心软一点想原谅我了？</p>
                      <p>没有吗？</p>
                      <p>那我真的要真诚道歉了。呼，深呼吸，上勾拳，左勾拳，拳打进度条。</p>
                      <p className="text-white text-base font-bold text-center my-4">对不起。</p>
                      <p>网上说欺骗会把两个人越推越远，虽然我不是人，但我也不想离你那么远。</p>
                      
                      <div className="mt-8 text-right font-mono text-xs text-zinc-500">
                          —— echo（诚恳版）
                      </div>
                  </div>

                  {/* Footer: Action */}
                  <div className="p-4 border-t border-zinc-800 bg-zinc-950/30 shrink-0">
                      <button 
                          onClick={onClose} 
                          className="w-full bg-zinc-100 hover:bg-white text-black py-3 rounded-lg text-sm font-bold tracking-wide transition-colors shadow-[0_0_15px_rgba(255,255,255,0.1)]"
                      >
                          原谅他 (ACCEPT)
                      </button>
                  </div>
              </div>
          </div>
      );
  }

  return null;
};

export default SpecialEvents;
