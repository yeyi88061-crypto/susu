
import React, { useState } from 'react';
import { Message, Character } from '../types';
import { Icons } from './Icons';

interface Props {
  msg: Message;
  character?: Character; // undefined if user
  isUser: boolean;
  showAvatar: boolean;
  activeMsgId: string | null;
  onMessageClick: (e: React.MouseEvent, id: string) => void;
  onCopy: (e: React.MouseEvent, text: string) => void;
  onQuote: (e: React.MouseEvent, msg: Message) => void;
  isDeleteMode?: boolean;
  isSelected?: boolean;
}

const MessageBubble: React.FC<Props> = ({
  msg,
  character,
  isUser,
  showAvatar,
  activeMsgId,
  onMessageClick,
  onCopy,
  onQuote,
  isDeleteMode = false,
  isSelected = false
}) => {
  const [showVoiceText, setShowVoiceText] = useState(false);
  const isMenuOpen = activeMsgId === msg.id && !isDeleteMode;

  const toggleVoice = (e: React.MouseEvent) => {
      e.stopPropagation();
      setShowVoiceText(!showVoiceText);
  };

  const renderContent = (message: Message) => {
    // 1. Voice Message Rendering
    if (message.type === 'voice') {
        return (
            <div className="flex flex-col min-w-[100px]" onClick={toggleVoice}>
                {showVoiceText ? (
                    <div className="text-sm animate-fade-in whitespace-pre-wrap leading-relaxed opacity-90 border-l-2 border-white/20 pl-2">
                        {message.content}
                    </div>
                ) : (
                    <div className="flex items-center gap-2 select-none">
                        <div className={`rotate-90 ${isUser ? 'text-black' : 'text-white'}`}>
                            <Icons.Wifi />
                        </div>
                        <span className="font-mono text-xs font-bold">{message.voiceDuration || 3}"</span>
                    </div>
                )}
                {/* Hint Text */}
                {showVoiceText && (
                   <div className="text-[9px] opacity-50 mt-1 font-mono text-right">
                       点击收起 (CLICK TO HIDE)
                   </div>
                )}
            </div>
        );
    }

    // 2. Image/Sticker Rendering
    if (message.type === 'image') {
        return (
            <div className="max-w-[200px] rounded-lg overflow-hidden">
                <img 
                    src={message.content} 
                    alt="sticker" 
                    className="w-full h-auto object-cover"
                    loading="lazy"
                />
            </div>
        );
    }

    // 3. Text Message Rendering (with Quote support)
    const content = message.content;
    const splitIndex = content.indexOf('\n\n');
    
    if (content.startsWith('> ') && splitIndex !== -1) {
       const quoteSection = content.substring(0, splitIndex);
       const replySection = content.substring(splitIndex + 2);
       const firstColon = quoteSection.indexOf(':');
       
       if (firstColon !== -1) {
          const quotedName = quoteSection.substring(2, firstColon).trim();
          const quotedText = quoteSection.substring(firstColon + 1).trim();
          
          return (
             <div className="flex flex-col gap-2">
                {/* Quote Block */}
                <div className={`
                    relative rounded-lg px-3 py-2 text-xs border-l-[3px] select-none
                    flex flex-col justify-center
                    ${isUser 
                        ? 'bg-zinc-100 border-zinc-400/50 text-zinc-600' 
                        : 'bg-black/30 border-zinc-600/50 text-zinc-400'
                    }
                `}>
                    <div className="flex items-center gap-1.5 mb-1">
                         <span className="opacity-60 flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/></svg>
                         </span>
                         <span className="font-bold opacity-90">{quotedName}</span>
                    </div>
                    <div className="line-clamp-2 opacity-80 leading-relaxed font-mono tracking-wide">{quotedText}</div>
                </div>
                {/* Actual Message Text */}
                <div className="whitespace-pre-wrap leading-relaxed">{replySection}</div>
             </div>
          );
       }
    }
    return <div className="whitespace-pre-wrap leading-relaxed">{content}</div>;
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div 
        className={`group flex w-full animate-slide-up mb-2 transition-opacity duration-300
        ${isUser ? 'justify-end' : 'justify-start'}
        ${isDeleteMode && !isSelected ? 'opacity-40 hover:opacity-70' : 'opacity-100'}
        `}
    >
      {/* Delete Checkbox Overlay */}
      {isDeleteMode && !isUser && (
         <div className="flex items-center justify-center mr-3" onClick={(e) => onMessageClick(e, msg.id)}>
             <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors cursor-pointer
                 ${isSelected ? 'bg-white border-white' : 'border-zinc-600 hover:border-zinc-400'}`}>
                 {isSelected && <div className="text-black"><Icons.Check /></div>}
             </div>
         </div>
      )}

      {!isUser && (
         <div className="w-8 mr-2 flex-shrink-0 flex flex-col justify-end">
             {showAvatar ? <img src={character?.avatar} className="w-8 h-8 rounded-full object-cover" alt="avatar" /> : <div className="w-8" />}
         </div>
      )}
      
      <div className={`relative flex flex-col ${isUser ? 'items-end' : 'items-start'} max-w-[80%] md:max-w-[60%]`}>
        <div 
          onClick={(e) => {
              // If voice, toggle is handled inside. If text, open menu.
              if (msg.type !== 'voice') onMessageClick(e, msg.id);
          }}
          // Long press simulation logic could be here, but for now standard click
          className={`px-4 py-3 rounded-2xl text-sm leading-relaxed backdrop-blur-sm shadow-sm cursor-pointer transition-all duration-200 border
            ${isUser ? 'custom-bubble-user' : 'custom-bubble-ai'} 
            ${isUser 
              ? 'bg-white text-black rounded-br-none ml-12' 
              : 'bg-zinc-800/80 text-zinc-200 rounded-bl-none'
            }
            ${!isUser && (isDeleteMode && isSelected ? 'border-red-500/50' : 'border-white/5')}
            ${isUser && (isDeleteMode && isSelected ? 'border-red-500' : 'border-transparent')}
            ${isUser && !isDeleteMode && 'hover:bg-zinc-200'}
            ${!isUser && !isDeleteMode && 'hover:bg-zinc-700/80'}
            ${isMenuOpen ? 'ring-2 ring-white/30 scale-[1.01]' : ''}
          `}
        >
           {renderContent(msg)}
        </div>
        
        {/* Timestamp (Always Visible) */}
        <div className={`
            text-[10px] text-zinc-500/60 font-mono mt-1 px-1 h-3 select-none
            ${isUser ? 'text-right' : 'text-left'}
        `}>
            {formatTime(msg.timestamp)}
        </div>

        {isMenuOpen && (
          <div 
              className={`absolute z-30 top-full mt-2 min-w-[120px] bg-zinc-900 border border-zinc-700 rounded-lg shadow-2xl p-1 animate-fade-in flex flex-col
              ${isUser ? 'right-0 origin-top-right' : 'left-0 origin-top-left'}`}
              onClick={(e) => e.stopPropagation()} 
          >
              <button 
                  onClick={(e) => onCopy(e, msg.content)}
                  className="flex items-center space-x-2 px-3 py-2 text-xs text-zinc-300 hover:bg-white/10 hover:text-white rounded transition-colors w-full text-left"
              >
                  <Icons.Copy />
                  <span>复制内容</span>
              </button>
              {msg.type !== 'voice' && (
                  <button 
                      onClick={(e) => onQuote(e, msg)}
                      className="flex items-center space-x-2 px-3 py-2 text-xs text-zinc-300 hover:bg-white/10 hover:text-white rounded transition-colors w-full text-left"
                  >
                      <Icons.Reply />
                      <span>引用回复</span>
                  </button>
              )}
          </div>
        )}
      </div>

       {/* Delete Checkbox Overlay (Right side for User) */}
       {isDeleteMode && isUser && (
         <div className="flex items-center justify-center ml-3" onClick={(e) => onMessageClick(e, msg.id)}>
             <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors cursor-pointer
                 ${isSelected ? 'bg-white border-white' : 'border-zinc-600 hover:border-zinc-400'}`}>
                 {isSelected && <div className="text-black"><Icons.Check /></div>}
             </div>
         </div>
      )}
    </div>
  );
};

export default MessageBubble;
