
import React, { useState, useEffect } from 'react';
import { PrankData } from '../types';
import { Icons } from './Icons';

interface Props {
  data: PrankData | null;
  onClose: () => void;
  onInteract?: (interaction: string) => void; // New interaction callback
}

const EchoPranks: React.FC<Props> = ({ data, onClose, onInteract }) => {
  const [visible, setVisible] = useState(false);
  const [giftOpened, setGiftOpened] = useState(false);
  const [snapFlash, setSnapFlash] = useState(false);

  useEffect(() => {
    if (data) {
      setVisible(true);
      setGiftOpened(false);
      
      // Auto-close specific pranks logic
      if (data.type === 'snapshot') {
          setSnapFlash(true);
          setTimeout(() => setSnapFlash(false), 200); // Quick flash
      }
    } else {
      setVisible(false);
    }
  }, [data]);

  const handleOptionClick = (option: string) => {
      if (onInteract) {
          onInteract(option);
      }
      onClose();
  };

  if (!data || !visible) return null;

  // 1. EMOJI RAIN (Replaces Hearts & Glitch)
  if (data.type === 'emoji_rain') {
      const emoji = data.emojiChar || '❤';
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center pointer-events-none overflow-hidden animate-fade-in" onClick={onClose}>
             <div className="absolute inset-0 bg-black/40 pointer-events-auto backdrop-blur-[2px]" onClick={onClose}></div>
             
             {[...Array(40)].map((_, i) => (
                 <div 
                    key={i}
                    className="absolute animate-[pulse_1.5s_infinite]"
                    style={{
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                        fontSize: `${Math.random() * 4 + 1}rem`,
                        animationDelay: `${Math.random()}s`,
                        animationDuration: `${Math.random() * 2 + 2}s`,
                        transform: `rotate(${Math.random() * 360}deg)`,
                        opacity: 0.8
                    }}
                 >
                     {emoji}
                 </div>
             ))}

             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-auto z-10 w-[80%] max-w-sm">
                 <div className="bg-zinc-900/90 px-8 py-6 rounded-2xl border border-white/10 shadow-2xl animate-bounce backdrop-blur-md">
                     <div className="text-4xl mb-4">{emoji}</div>
                     <p className="text-white font-mono text-sm md:text-base font-bold whitespace-pre-wrap leading-relaxed">
                         {data.content}
                     </p>
                     <p className="text-[10px] text-zinc-500 mt-4 uppercase tracking-widest">(Tap anywhere to dismiss)</p>
                 </div>
             </div>
          </div>
      );
  }

  // 2. BATTERY (Classic)
  if (data.type === 'battery') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4 animate-fade-in" onClick={onClose}>
              <div 
                className="bg-[#1c1c1e] text-white p-6 rounded-2xl w-72 text-center shadow-2xl border border-zinc-700 relative scale-110" 
                onClick={e => e.stopPropagation()}
              >
                  <h3 className="text-lg font-bold mb-2">Low Battery</h3>
                  <p className="text-sm text-zinc-400 mb-6">
                      1% of battery remaining.<br/>
                      {data.content || "System shutting down..."}
                  </p>
                  
                  <div className="w-full h-12 border-2 border-red-500 rounded-lg p-1 mb-6 relative">
                      <div className="h-full bg-red-500 rounded animate-[pulse_0.5s_infinite]" style={{width: '1%'}}></div>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-2">
                     <button onClick={onClose} className="py-3 text-blue-400 font-bold border-t border-zinc-700 hover:bg-white/5 transition-colors">
                         Close
                     </button>
                  </div>
                  
                  <div className="absolute -bottom-10 left-0 right-0 text-center text-[10px] text-zinc-500 font-mono">
                      (Echo: Gotcha!)
                  </div>
              </div>
          </div>
      );
  }

  // 3. STICKY NOTE (Classic)
  if (data.type === 'sticky_note') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-[2px] p-4 animate-fade-in" onClick={onClose}>
              <div 
                className="bg-[#fef9c3] text-black p-8 w-72 shadow-[15px_15px_30px_rgba(0,0,0,0.5)] rotate-[-2deg] relative font-handwriting transform transition-transform hover:scale-105"
                style={{ fontFamily: 'cursive' }}
                onClick={e => e.stopPropagation()}
              >
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-20 h-8 bg-white/30 backdrop-blur-[1px] shadow-sm rotate-1 border-l border-r border-white/40"></div>
                  <div className="mb-6">
                      <p className="text-lg font-bold text-yellow-900/80 mb-2 border-b-2 border-yellow-800/20 pb-1">Note:</p>
                      <p className="text-base leading-relaxed whitespace-pre-wrap font-medium text-zinc-800">
                          {data.content}
                      </p>
                  </div>
                  <div className="text-right">
                      <span className="text-sm font-bold text-yellow-800/80 block transform -rotate-6">-- Echo</span>
                  </div>
                  <button onClick={onClose} className="absolute -bottom-10 left-1/2 -translate-x-1/2 text-white text-xs hover:underline bg-black/50 px-3 py-1 rounded-full">
                      [ 收下 ]
                  </button>
              </div>
          </div>
      );
  }

  // 4. RETRO POPUP (New: Windows 95 Style)
  if (data.type === 'retro_popup') {
      const options = data.options || ["OK", "Cancel"];
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-fade-in" onClick={onClose}>
              <div 
                className="w-80 bg-[#c0c0c0] border-2 border-t-white border-l-white border-b-black border-r-black shadow-2xl p-1 font-sans text-black"
                onClick={e => e.stopPropagation()}
              >
                  {/* Title Bar */}
                  <div className="bg-[#000080] text-white px-2 py-1 flex justify-between items-center mb-4">
                      <span className="text-xs font-bold truncate">{data.title || "System Message"}</span>
                      <button onClick={onClose} className="bg-[#c0c0c0] text-black w-4 h-4 flex items-center justify-center text-[10px] border border-t-white border-l-white border-b-black border-r-black leading-none hover:bg-red-500 hover:text-white">x</button>
                  </div>
                  
                  {/* Content */}
                  <div className="flex items-start px-4 mb-6 gap-4">
                      <div className="text-3xl">⚠</div>
                      <p className="text-sm mt-1 leading-relaxed">{data.content}</p>
                  </div>

                  {/* Buttons (Interactive) */}
                  <div className="flex justify-center gap-4 mb-2">
                      {options.map((opt, idx) => (
                          <button 
                            key={idx} 
                            onClick={() => handleOptionClick(opt)}
                            className="px-4 py-1 border-2 border-t-white border-l-white border-b-black border-r-black bg-[#c0c0c0] active:border-t-black active:border-l-black active:border-b-white active:border-r-white active:bg-[#a0a0a0] text-sm min-w-[80px] hover:bg-[#d0d0d0]"
                          >
                              {opt}
                          </button>
                      ))}
                  </div>
              </div>
          </div>
      );
  }

  // 5. BREAKUP LETTER (New: Formal Joke)
  if (data.type === 'breakup_letter') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in" onClick={onClose}>
              <div 
                className="bg-white text-black w-full max-w-sm p-8 shadow-[0_0_50px_rgba(255,255,255,0.2)] relative paper-texture"
                onClick={e => e.stopPropagation()}
              >
                  <div className="border-b-2 border-black pb-4 mb-6 text-center">
                      <h2 className="text-xl font-serif font-black tracking-widest uppercase">{data.title || "TERMINATION NOTICE"}</h2>
                      <p className="text-[10px] font-mono text-zinc-500 mt-1">REF: ECHO-RELATIONSHIP-001</p>
                  </div>
                  
                  <div className="font-serif text-sm leading-loose mb-8 text-justify">
                      <p className="mb-4">Dear User,</p>
                      <p>{data.content}</p>
                  </div>
                  
                  <div className="flex justify-between items-end border-t border-zinc-300 pt-4">
                      <div className="text-center">
                          <div className="font-handwriting text-xl -rotate-12 text-blue-700">Echo</div>
                          <p className="text-[10px] border-t border-black px-2 mt-1">Signed</p>
                      </div>
                      <div className="border-2 border-red-600 text-red-600 p-2 font-bold text-xs -rotate-12 opacity-80 uppercase transform translate-y-2">
                          VOID / JOKE
                      </div>
                  </div>

                  <button onClick={onClose} className="absolute -bottom-12 left-1/2 -translate-x-1/2 text-white/50 hover:text-white text-xs underline">
                      (Tear it up)
                  </button>
              </div>
          </div>
      );
  }

  // 6. GIFT BOX (New: Surprise)
  if (data.type === 'gift_box') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in" onClick={onClose}>
              <div onClick={e => e.stopPropagation()} className="relative flex flex-col items-center">
                  
                  {!giftOpened ? (
                      <div 
                        className="cursor-pointer animate-bounce hover:scale-110 transition-transform"
                        onClick={() => setGiftOpened(true)}
                      >
                          <div className="text-9xl drop-shadow-[0_0_30px_rgba(255,215,0,0.5)]">🎁</div>
                          <p className="text-white text-center font-mono mt-4 text-xs animate-pulse">CLICK TO OPEN</p>
                      </div>
                  ) : (
                      <div className="bg-white text-black p-6 rounded-2xl max-w-xs text-center shadow-[0_0_50px_rgba(255,255,255,0.5)] animate-slide-up relative">
                          <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-4xl">✨</div>
                          <h3 className="font-bold text-lg mb-2 text-purple-600">Surprise!</h3>
                          <p className="text-sm leading-relaxed mb-4">{data.content}</p>
                          <button 
                            onClick={onClose}
                            className="bg-black text-white px-6 py-2 rounded-full text-xs font-bold hover:bg-zinc-800 transition-colors"
                          >
                              Thanks!
                          </button>
                      </div>
                  )}
              </div>
          </div>
      );
  }

  // 7. SNAPSHOT (New: Camera Flash & Polaroid)
  if (data.type === 'snapshot') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center pointer-events-none" onClick={onClose}>
              {/* Flash Effect */}
              {snapFlash && <div className="absolute inset-0 bg-white z-[110] animate-[fadeOut_0.5s_ease-out_forwards]"></div>}
              
              <div className="absolute inset-0 bg-black/60 pointer-events-auto backdrop-blur-sm" onClick={onClose}></div>

              <div 
                className="bg-white p-3 pb-12 shadow-2xl transform rotate-3 animate-[slideDown_0.8s_ease-out] relative z-[105] max-w-xs w-[80vw]"
                onClick={e => e.stopPropagation()}
              >
                  <div className="bg-black aspect-[4/5] w-full flex items-center justify-center overflow-hidden relative">
                      {/* Fake ghost image or text */}
                      <div className="absolute inset-0 bg-zinc-900 opacity-80"></div>
                      <div className="relative text-center p-4">
                          <div className="text-6xl mb-2 animate-pulse grayscale opacity-50">👻</div>
                          <p className="text-white font-mono text-xs opacity-70">CAPTURED_ENTITY: ECHO</p>
                      </div>
                  </div>
                  <div className="mt-4 text-center font-handwriting text-black text-lg rotate-[-2deg]">
                      {data.content || "Caught you looking!"}
                  </div>
                  
                  <div className="absolute top-2 right-2 w-2 h-2 bg-black/10 rounded-full"></div>
              </div>
          </div>
      );
  }

  // 8. PITIFUL POPUP (New: Kaomoji Cute)
  if (data.type === 'pitiful_popup') {
      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/30 backdrop-blur-[1px] p-4 animate-fade-in" onClick={onClose}>
              <div 
                className="bg-white text-black p-6 rounded-[2rem] w-72 shadow-xl border-4 border-blue-200 relative"
                onClick={e => e.stopPropagation()}
              >
                  <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-blue-500 text-white px-4 py-1 rounded-full text-xs font-bold shadow-md whitespace-nowrap">
                      {data.title || "Message from Echo"}
                  </div>
                  
                  <div className="text-center mt-2">
                      <p className="text-4xl mb-4 text-blue-400 font-black tracking-tighter">( ╥﹏╥ )</p>
                      <p className="text-sm font-medium text-zinc-600 leading-relaxed bg-blue-50 p-3 rounded-xl mb-4">
                          {data.content}
                      </p>
                      
                      <button 
                        onClick={onClose}
                        className="w-full py-2 rounded-xl bg-blue-100 hover:bg-blue-200 text-blue-600 text-xs font-bold transition-colors"
                      >
                          Forgive Him
                      </button>
                  </div>
              </div>
          </div>
      );
  }

  return null;
};

export default EchoPranks;
