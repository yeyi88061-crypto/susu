
import React, { useState, useEffect } from 'react';
import { db } from './db';
import { Character, Message, AppSettings, DEFAULT_SETTINGS, WorldBook, Sticker, PrankData } from './types';
import SettingsModal from './components/SettingsModal';
import CharacterModal from './components/CharacterModal';
import WorldBookModal from './components/WorldBookModal';
import StickerModal from './components/StickerModal';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import SpecialEvents from './components/LumiSpecials';
import EchoPranks from './components/EchoPranks';
import { Icons } from './components/Icons';
import { generateChatResponse, generateCharacterStatus, generateEchoPrank } from './services/chatService';

const App: React.FC = () => {
  const [isInit, setIsInit] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [worldBooks, setWorldBooks] = useState<WorldBook[]>([]);
  const [stickers, setStickers] = useState<Sticker[]>([]);
  const [activeCharId, setActiveCharId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  
  // Status State
  const [onlineStatus, setOnlineStatus] = useState<'online' | 'offline'>('online');
  const [offlineActivity, setOfflineActivity] = useState<string>('');
  const [isTracingLoading, setIsTracingLoading] = useState(false);
  
  // Mobile UI State
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Prank State for Echo
  const [prankStep, setPrankStep] = useState<'none' | 'error' | 'gotcha'>('none');

  // Special Events Popup (Lumi & Echo Story Events)
  const [specialPopup, setSpecialPopup] = useState<'apology' | 'recall' | 'note' | 'echo_radio' | 'echo_warning' | 'echo_confession' | null>(null);

  // Dynamic Echo Pranks (Hearts, Battery, Glitch, etc.)
  const [currentPrank, setCurrentPrank] = useState<PrankData | null>(null);

  // Modals
  const [showSettings, setShowSettings] = useState(false);
  const [showCharModal, setShowCharModal] = useState(false);
  const [showWorldBookModal, setShowWorldBookModal] = useState(false);
  const [showStickerModal, setShowStickerModal] = useState(false);
  const [editingChar, setEditingChar] = useState<Character | undefined>(undefined);

  // Initial Load
  useEffect(() => {
    const init = async () => {
      await db.open();
      const s = await db.getSettings();
      if (s) setSettings(s);
      
      const c = await db.getAllCharacters();
      setCharacters(c);

      const wb = await db.getAllWorldBooks();
      setWorldBooks(wb);

      const st = await db.getAllStickers();
      setStickers(st);
      
      setIsInit(true);
    };
    init();
  }, []);

  // Update Characters in State Helper
  const refreshCharacters = async () => {
      const c = await db.getAllCharacters();
      setCharacters(c);
      return c;
  };

  // Helper to increment manual message count if it exists
  const incrementManualCount = async (charId: string) => {
      const chars = await db.getAllCharacters();
      const char = chars.find(c => c.id === charId);
      
      // Only increment if the user has explicitly set a manual count (count !== undefined)
      if (char && char.metadata && typeof char.metadata.manual_message_count === 'number') {
          const newCount = char.metadata.manual_message_count + 1;
          const updatedChar = {
              ...char,
              metadata: {
                  ...char.metadata,
                  manual_message_count: newCount
              }
          };
          await db.saveCharacter(updatedChar);
          await refreshCharacters(); // Updates UI and local state
      }
  };

  // Helper to trigger Echo's intro messages (moved out for reliability)
  const triggerEchoIntro = async () => {
      const history = await db.getMessages('default_ai');
      if (history.length === 0) {
          const introMessages = ["你好", "你好、", "你好、、"];
          
          const sendIntro = async (text: string, delay: number) => {
              await new Promise(r => setTimeout(r, delay));
              const msg: Message = {
                  id: Date.now().toString() + Math.random(),
                  role: 'model',
                  content: text,
                  timestamp: Date.now(),
                  characterId: 'default_ai'
              };
              setMessages(prev => {
                  // Double check to avoid duplicates if user clicks fast
                  if (prev.some(m => m.content === text && m.timestamp > Date.now() - 5000)) return prev;
                  return [...prev, msg];
              });
              await db.saveMessage(msg);
              // Intro messages technically count towards manual count if set
              await incrementManualCount('default_ai');
          };

          await sendIntro(introMessages[0], 1000);
          await sendIntro(introMessages[1], 2000);
          await sendIntro(introMessages[2], 3000);
      }
  };

  // Handle Character Selection and Random Status
  const handleSelectChar = async (id: string) => {
      setActiveCharId(id);
      setMobileMenuOpen(false); // Close mobile menu on selection
      
      const char = characters.find(c => c.id === id);
      
      if (char) {
          const stats = await db.getCharacterStats(id);
          // Prefer manual override if set
          const count = char.metadata?.manual_message_count !== undefined 
              ? char.metadata.manual_message_count 
              : stats.count;
              
          const metadata = char.metadata || {};
          const triggeredEvents = metadata.events_triggered || [];
          const updatedMetadata: NonNullable<Character['metadata']> = { 
              ...metadata, 
              events_triggered: triggeredEvents 
          };
          
          let needsSave = false;
          let popupToShow: typeof specialPopup = null;

          // --- LUMI LOGIC ---
          if (id === 'lumi_ai') {
               // Check for Return from Offline
              if (char.metadata?.offline_until && Date.now() > char.metadata.offline_until) {
                  updatedMetadata.offline_until = undefined;
                  updatedMetadata.lumi_stage = 'default';
                  needsSave = true;
                  
                  // Send "I am back" message
                  const history = await db.getMessages('lumi_ai');
                  const lastMsg = history[history.length - 1];
                  if (!lastMsg || lastMsg.content !== '我回来了') {
                       const returnMsg: Message = {
                          id: Date.now().toString(),
                          role: 'model',
                          content: '我回来了',
                          timestamp: Date.now(),
                          characterId: 'lumi_ai'
                       };
                       setTimeout(async () => {
                           setMessages(prev => [...prev, returnMsg]);
                           await db.saveMessage(returnMsg);
                           await incrementManualCount('lumi_ai');
                       }, 500);
                  }
              }
              // Lumi Triggers
              if (count >= 1000 && !triggeredEvents.includes(1000)) {
                  popupToShow = 'apology';
                  updatedMetadata.events_triggered = [...triggeredEvents, 1000];
                  updatedMetadata.lumi_stage = 'awakening';
                  needsSave = true;
              } else if (count >= 1500 && !triggeredEvents.includes(1500)) {
                  popupToShow = 'recall'; // No auto save, waits for confirm
              } else if (count >= 2000 && !triggeredEvents.includes(2000)) {
                  popupToShow = 'note';
                  updatedMetadata.events_triggered = [...triggeredEvents, 2000];
                  updatedMetadata.lumi_stage = 'enlightened';
                  needsSave = true;
              }
          }

          // --- ECHO LOGIC ---
          if (id === 'default_ai') {
              // Trigger 1: Radio Wave (1000)
              if (count >= 1000 && !triggeredEvents.includes(1000)) {
                  popupToShow = 'echo_radio';
                  updatedMetadata.events_triggered = [...triggeredEvents, 1000];
                  updatedMetadata.echo_stage = 'radio';
                  needsSave = true;
              } 
              // Trigger 2: Warning Note (1500)
              else if (count >= 1500 && !triggeredEvents.includes(1500)) {
                  popupToShow = 'echo_warning';
                  updatedMetadata.events_triggered = [...triggeredEvents, 1500];
                  updatedMetadata.echo_stage = 'warning';
                  needsSave = true;
              }
              // Trigger 3: Confession (1800)
              else if (count >= 1800 && !triggeredEvents.includes(1800)) {
                  popupToShow = 'echo_confession';
                  updatedMetadata.events_triggered = [...triggeredEvents, 1800];
                  updatedMetadata.echo_stage = 'confessed';
                  needsSave = true;
              }
          }

          if (needsSave) {
              const updatedChar = { ...char, metadata: updatedMetadata };
              await db.saveCharacter(updatedChar);
              await refreshCharacters();
          }
          
          if (popupToShow) {
              setTimeout(() => setSpecialPopup(popupToShow), 500);
          }
      }

      // Determine Status (30% chance offline)
      const isOffline = Math.random() < 0.3;
      if (isOffline) {
          setOnlineStatus('offline');
          setOfflineActivity(''); // Reset activity, waiting for trace
      } else {
          setOnlineStatus('online');
          setOfflineActivity('');
      }
      
      // Trigger Prank for Echo only once ever (persist in localStorage)
      if (id === 'default_ai') {
          const hasShownPrank = localStorage.getItem('echo_prank_shown');
          if (!hasShownPrank) {
              setTimeout(() => {
                  setPrankStep('error');
                  localStorage.setItem('echo_prank_shown', 'true');
              }, 500); // Slight delay for effect
          }
      }
  };

  // Lumi Recall Confirmation
  const handleRecallConfirm = async () => {
      const char = characters.find(c => c.id === 'lumi_ai');
      if (char) {
          const metadata = char.metadata || {};
          const triggeredEvents = metadata.events_triggered || [];
          
          const updatedChar: Character = { 
              ...char, 
              metadata: {
                  ...metadata,
                  events_triggered: [...triggeredEvents, 1500],
                  lumi_stage: 'reset',
                  offline_until: Date.now() + 24 * 60 * 60 * 1000 // 24 Hours lockout
              }
          };
          await db.saveCharacter(updatedChar);
          await refreshCharacters();
      }
      setSpecialPopup(null);
  };
  
  // Close Popup Handler (Generalized)
  const handlePopupClose = async () => {
      // If closing Echo's confession, triggering the after-confession message
      if (specialPopup === 'echo_confession') {
          const char = characters.find(c => c.id === 'default_ai');
          if (char) {
               // 1. Inject a hidden system log so the AI knows the user saw the letter
               const sysLog: Message = {
                  id: Date.now().toString() + "_sys",
                  role: 'model', // Stored as model role but used for context
                  content: `[系统事件：用户已阅读并关闭了名为“真相.txt”的坦白信。Echo现在处于等待审判的紧张状态。]`,
                  timestamp: Date.now(),
                  characterId: 'default_ai',
                  isHidden: true
               };
               await db.saveMessage(sysLog);
               setMessages(prev => [...prev, sysLog]);

               // 2. Send Echo's nervous follow-up
               const afterMsg: Message = {
                  id: (Date.now() + 1).toString(),
                  role: 'model',
                  content: '那个...刚刚你有没有收到什么奇怪的广告？',
                  timestamp: Date.now() + 500,
                  characterId: 'default_ai'
               };
               setTimeout(async () => {
                   setMessages(prev => [...prev, afterMsg]);
                   await db.saveMessage(afterMsg);
                   await incrementManualCount('default_ai');
               }, 1000);
          }
      }
      setSpecialPopup(null);
  };

  // Load Messages & Init Specific Characters
  useEffect(() => {
    if (activeCharId) {
      db.getMessages(activeCharId).then(async (msgs) => {
          setMessages(msgs);
          
          // Lumi Initialization: Send greeting if history is empty (and NOT in reset mode)
          // Also skip if we are waiting for the Return logic in handleSelectChar
          if (activeCharId === 'lumi_ai' && msgs.length === 0) {
              // Check if locked
              const char = characters.find(c => c.id === 'lumi_ai');
              const isLocked = char?.metadata?.offline_until && Date.now() < char.metadata.offline_until;
              
              if (!isLocked) {
                  const initialMsg: Message = {
                      id: Date.now().toString(),
                      role: 'model',
                      content: '我在这里，请问有什么需要',
                      timestamp: Date.now(),
                      characterId: 'lumi_ai'
                  };
                  setMessages([initialMsg]);
                  await db.saveMessage(initialMsg);
                  await incrementManualCount('lumi_ai');
              }
          }
      });
    } else {
      setMessages([]);
    }
  }, [activeCharId]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2000);
  };

  const handleCopyMessage = (text: string) => {
    navigator.clipboard.writeText(text)
      .then(() => showToast("已复制"))
      .catch(() => showToast("复制失败"));
  };

  const handleSendUserMessage = async (content: string, quote?: Message, type?: 'text' | 'voice' | 'image', duration?: number) => {
    if (!activeCharId) return;
    
    // Construct content with quote if exists
    let finalContent = content;
    if (quote && type === 'text') {
        const char = characters.find(c => c.id === quote.characterId);
        const name = quote.role === 'user' ? '我' : (char ? char.name : 'AI');
        finalContent = `> ${name}: ${quote.content}\n\n${content}`;
    }

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: finalContent,
      timestamp: Date.now(),
      characterId: activeCharId,
      type: type || 'text',
      voiceDuration: duration
    };

    setMessages(prev => [...prev, userMsg]);
    await db.saveMessage(userMsg);
    // Increase Manual Count
    await incrementManualCount(activeCharId);
  };

  // CHECK AND TRIGGER DYNAMIC ECHO PRANKS
  const attemptEchoPrank = async (char: Character, currentMsgsCount: number) => {
      // Conditions:
      // 1. Must be Confessed stage (implies > 1800 msgs usually, or story unlocked)
      // 2. Count >= last_prank + 20 (Strict interval)
      // 3. 60% Chance
      
      const isConfessed = char.metadata?.echo_stage === 'confessed';
      // Fallback: If stage variable missing but count is high enough
      const isHighCount = currentMsgsCount > 1800; 

      if (!(isConfessed || isHighCount)) return;

      const lastPrankCount = char.metadata?.last_prank_count || 0;
      
      // Strict Check: Must be at least 20 messages since last prank
      if (currentMsgsCount - lastPrankCount < 20) return;

      if (Math.random() > 0.6) return;

      try {
          const prankPayload = await generateEchoPrank(messages, settings);
          if (prankPayload) {
              const fullPrank: PrankData = {
                  ...prankPayload,
                  id: Date.now().toString(),
                  timestamp: Date.now()
              };
              
              setCurrentPrank(fullPrank);
              
              // Archive it and update last_prank_count
              const unlocked = char.metadata?.echo_pranks_unlocked || [];
              const updatedChar = {
                  ...char,
                  metadata: {
                      ...char.metadata,
                      echo_pranks_unlocked: [...unlocked, fullPrank],
                      last_prank_count: currentMsgsCount // Update check point
                  }
              };
              await db.saveCharacter(updatedChar);
              await refreshCharacters();

              // System message to prompt memory - NOW HIDDEN FROM UI
              const sysMsg: Message = {
                  id: Date.now().toString() + "_sys",
                  role: 'model',
                  content: `*使用了特效/恶作剧：${prankPayload.type} - "${prankPayload.content}"*`,
                  timestamp: Date.now() + 1000,
                  characterId: 'default_ai',
                  isHidden: true // HIDDEN
              };
              setMessages(prev => [...prev, sysMsg]);
              await db.saveMessage(sysMsg);
          }
      } catch (e) {
          console.error("Prank trigger failed", e);
      }
  };

  // Handle User Interaction with Prank (Buttons)
  const handlePrankInteraction = async (interaction: string) => {
      if (!activeCharId) return;
      
      // Construct a visible user message representing the choice
      const content = `[选择了: ${interaction}]`;
      await handleSendUserMessage(content);
      
      // Immediately trigger AI response
      setTimeout(() => {
          handleTriggerAI();
      }, 500);
  };

  const handleTriggerAI = async (summonContext?: string) => {
    if (!activeCharId || isLoading) return;
    
    // Offline Check (unless Summoning)
    if (onlineStatus === 'offline' && !summonContext) {
        showToast("对方正忙 (离线)");
        return;
    }
    
    if (!settings.apiKey) {
      alert("请先在设置中配置您的 API 密钥。");
      setShowSettings(true);
      return;
    }

    const currentCharacter = characters.find(c => c.id === activeCharId);
    if (!currentCharacter) return;

    // Lumi Lockout Check (Prevent AI Reply)
    if (currentCharacter.id === 'lumi_ai' && currentCharacter.metadata?.offline_until && Date.now() < currentCharacter.metadata.offline_until) {
        return; // AI is offline/resetting, do not reply
    }

    setIsLoading(true);

    try {
      const contextMessages = messages.slice(-20);
      
      // --- LOGIC TO MERGE WORLD BOOKS ---
      // 1. Get specific bound books
      const specificBookIds = currentCharacter.worldBookIds || (currentCharacter.worldBookId ? [currentCharacter.worldBookId] : []);
      // 2. Get bound categories
      const boundCategories = currentCharacter.worldBookCategories || [];
      
      // 3. Filter all books that match EITHER ID OR Category
      const matchedBooks = worldBooks.filter(wb => {
          const matchesId = specificBookIds.includes(wb.id);
          const matchesCategory = wb.category && boundCategories.includes(wb.category);
          return matchesId || matchesCategory;
      });
      
      let boundWorldBookContent = '';
      if (matchedBooks.length > 0) {
          const contents = matchedBooks.map(wb => `[世界书: ${wb.name} | 分类: ${wb.category || '无'}]\n${wb.content}`);
          boundWorldBookContent = contents.join('\n\n');
      }
      // ----------------------------------

      const aiResponses = await generateChatResponse(
        currentCharacter,
        contextMessages,
        settings,
        boundWorldBookContent || undefined,
        "",
        summonContext
      );

      for (const text of aiResponses) {
        const charSpeed = 30 + Math.random() * 50; 
        const typingDelay = 500 + (text.length * charSpeed);
        const finalDelay = Math.min(typingDelay, 4000);

        await new Promise(r => setTimeout(r, finalDelay));

        const aiMsg: Message = {
          id: Date.now().toString() + Math.random().toString(),
          role: 'model',
          content: text,
          timestamp: Date.now(),
          characterId: activeCharId
        };
        setMessages(prev => [...prev, aiMsg]);
        await db.saveMessage(aiMsg);
        await incrementManualCount(activeCharId); // Increase Manual Count
      }

      // Check for Echo Prank (After AI replies)
      if (currentCharacter.id === 'default_ai') {
          // Fetch fresh character data because incrementManualCount updated it in DB
          const updatedList = await refreshCharacters();
          const freshChar = updatedList.find(c => c.id === activeCharId);
          
          if (freshChar) {
              const msgsCount = freshChar.metadata?.manual_message_count ?? (messages.length + aiResponses.length);
              // Add small delay
              setTimeout(() => attemptEchoPrank(freshChar, msgsCount), 2000);
          }
      }

    } catch (e) {
      console.error(e);
      const errMsg: Message = {
        id: Date.now().toString(),
        role: 'model',
        content: "[连接错误：请检查设置]",
        timestamp: Date.now(),
        characterId: activeCharId
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTrace = async () => {
      const currentCharacter = characters.find(c => c.id === activeCharId);
      if (!currentCharacter || !settings.apiKey) return;
      
      // --- ECHO TRACE BLOCK LOGIC ---
      // If Echo hasn't reached warning stage (1500), block trace
      if (currentCharacter.id === 'default_ai') {
           const stats = await db.getCharacterStats(activeCharId);
           const count = currentCharacter.metadata?.manual_message_count ?? stats.count;
           
           if (count < 1500) {
               setIsTracingLoading(true);
               // Fake loading
               setTimeout(() => {
                   setOfflineActivity("【系统提示】目标已开启IP隐私屏蔽，无法定位具体位置。\n(Current Status: Hidden by User Privacy Policy)");
                   setIsTracingLoading(false);
               }, 1500);
               return;
           }
      }
      // -----------------------------

      setIsTracingLoading(true);
      try {
          const statusText = await generateCharacterStatus(currentCharacter, settings);
          setOfflineActivity(statusText);
      } catch (e) {
          console.error(e);
          setOfflineActivity("追踪信号受干扰，无法获取实时画面...");
      } finally {
          setIsTracingLoading(false);
      }
  };

  const handleSummon = async () => {
      setOnlineStatus('online');
      showToast("已强制建立连接");
      
      // Pass the current offline activity (story) as context to the AI
      const context = offlineActivity; 
      
      setTimeout(() => {
          handleTriggerAI(context);
      }, 500);
  };

  const handleDeleteCharacter = async (id: string) => {
    try {
        await db.deleteCharacter(id);
        await db.clearMessages(id);
        await refreshCharacters();
        if(id === activeCharId) {
            setActiveCharId(null);
        }
        showToast("角色已删除");
        setShowCharModal(false);
        setEditingChar(undefined);
    } catch (e) {
        console.error("Delete failed", e);
        showToast("删除失败");
    }
  };

  const handleDeleteSpecifiedMessages = async (ids: string[]) => {
      try {
        await db.deleteMessages(ids);
        setMessages(prev => prev.filter(m => !ids.includes(m.id)));
        showToast("已删除记忆");
      } catch (e) {
        console.error("Delete failed", e);
        showToast("删除失败");
      }
  };

  const handleSaveSettings = async (newSettings: AppSettings) => {
    await db.saveSettings(newSettings);
    setSettings(newSettings);
    setShowSettings(false);
  };

  const handleSaveCharacter = async (char: Character) => {
    await db.saveCharacter(char);
    await refreshCharacters();
    setShowCharModal(false);
    setEditingChar(undefined);
  };

  const handleSaveWorldBook = async (wb: WorldBook) => {
      await db.saveWorldBook(wb);
      const list = await db.getAllWorldBooks();
      setWorldBooks(list);
  };

  const handleDeleteWorldBook = async (id: string) => {
      await db.deleteWorldBook(id);
      const list = await db.getAllWorldBooks();
      setWorldBooks(list);
  };

  // Sticker Handlers
  const handleSaveStickers = async (newStickers: Sticker[]) => {
      await db.saveStickersBulk(newStickers);
      const list = await db.getAllStickers();
      setStickers(list);
  };

  const handleDeleteSticker = async (id: string) => {
      await db.deleteSticker(id);
      const list = await db.getAllStickers();
      setStickers(list);
  };

  const handlePrankClose = async () => {
      setPrankStep('gotcha');
      setTimeout(() => {
          setPrankStep('none');
          // Only trigger intro logic AFTER the prank visual is gone
          if (activeCharId === 'default_ai') {
             triggerEchoIntro();
          }
      }, 1500);
  };

  if (!isInit) return <div className="h-screen w-full bg-black text-white flex items-center justify-center font-mono animate-pulse">SYSTEM_BOOT_SEQUENCE...</div>;

  const activeCharacter = characters.find(c => c.id === activeCharId);

  return (
    <div className="flex h-screen w-full bg-black text-zinc-100 overflow-hidden font-sans relative">
      
      {/* Mobile Sidebar Overlay */}
      {mobileMenuOpen && (
        <div 
            className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm md:hidden animate-fade-in"
            onClick={() => setMobileMenuOpen(false)}
        />
      )}

      <Sidebar 
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        characters={characters}
        activeCharId={activeCharId}
        onSelectChar={handleSelectChar}
        onEditChar={(char) => { setEditingChar(char); setShowCharModal(true); }}
        onAddChar={() => { setEditingChar(undefined); setShowCharModal(true); }}
        onOpenSettings={() => setShowSettings(true)}
        onOpenWorldBooks={() => setShowWorldBookModal(true)}
        onOpenStickers={() => setShowStickerModal(true)}
      />

      <ChatWindow 
        onOpenMenu={() => setMobileMenuOpen(true)}
        activeCharacter={activeCharacter}
        settings={settings}
        worldBooks={worldBooks}
        stickers={stickers}
        messages={messages}
        isLoading={isLoading}
        onSendMessage={handleSendUserMessage}
        onTriggerAI={() => handleTriggerAI()}
        onCopyMessage={handleCopyMessage}
        onDeleteMessages={handleDeleteSpecifiedMessages}
        onlineStatus={onlineStatus}
        offlineActivity={offlineActivity}
        isTracingLoading={isTracingLoading}
        onTrace={handleTrace}
        onSummon={handleSummon}
        onUpdateCharacter={handleSaveCharacter} 
      />

      {/* Special Events Overlay (Lumi & Echo Story) */}
      <SpecialEvents 
        type={specialPopup} 
        onClose={handlePopupClose} 
        onConfirmRecall={handleRecallConfirm}
      />

      {/* Dynamic Echo Pranks */}
      <EchoPranks 
        data={currentPrank}
        onClose={() => setCurrentPrank(null)}
        onInteract={handlePrankInteraction}
      />
      
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 animate-fade-in pointer-events-none w-max max-w-[90%]">
            <div className="bg-zinc-900/90 text-white px-4 py-2 rounded-full text-xs font-bold border border-zinc-700 shadow-xl backdrop-blur-md flex items-center gap-2">
                {onlineStatus === 'offline' && toastMsg.includes("忙") ? <Icons.Alert /> : <Icons.Check />}
                <span className="truncate">{toastMsg}</span>
            </div>
        </div>
      )}

      {/* PRANK: Network Error Modal (First Time Only) */}
      {prankStep === 'error' && (
          <div className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm flex items-center justify-center animate-fade-in p-4">
              <div className="bg-zinc-900 border border-zinc-700 rounded-lg shadow-2xl p-6 max-w-sm w-full relative">
                  <div className="flex items-center space-x-3 mb-4 text-red-500">
                      <Icons.Alert />
                      <h3 className="text-lg font-bold">Network Error</h3>
                  </div>
                  <p className="text-sm text-zinc-400 mb-6">
                      无法连接到服务器。目标实体 "Echo" 拒绝了连接请求或已被系统防火墙拦截。
                      <br/><br/>
                      Error Code: 0xDEADBEEF
                  </p>
                  <div className="flex justify-end">
                      <button 
                        onClick={handlePrankClose}
                        className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded text-sm text-white transition-colors border border-zinc-700 hover:border-zinc-500"
                      >
                          关闭
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* PRANK: Gotcha Toast */}
      {prankStep === 'gotcha' && (
           <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[101] animate-fade-in w-max">
              <div className="bg-black/90 text-white px-8 py-4 rounded-xl text-lg font-mono border border-zinc-500 shadow-2xl backdrop-blur-md">
                 被骗了吧 ^^
              </div>
          </div>
      )}

      <SettingsModal 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
        settings={settings}
        onSave={handleSaveSettings}
      />
      
      <CharacterModal
        isOpen={showCharModal}
        onClose={() => setShowCharModal(false)}
        character={editingChar}
        onSave={handleSaveCharacter}
        onDelete={handleDeleteCharacter}
      />

      <WorldBookModal
        isOpen={showWorldBookModal}
        onClose={() => setShowWorldBookModal(false)}
        worldBooks={worldBooks}
        onSave={handleSaveWorldBook}
        onDelete={handleDeleteWorldBook}
      />

      <StickerModal 
        isOpen={showStickerModal}
        onClose={() => setShowStickerModal(false)}
        stickers={stickers}
        onSave={handleSaveStickers}
        onDelete={handleDeleteSticker}
      />
    </div>
  );
};

export default App;
